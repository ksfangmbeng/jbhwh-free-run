import { vehicles } from "@/lib/vehicle-data"
import { VehicleCard } from "./vehicle-card"

export function VehicleGrid() {
  return (
    <section className="flex-1 bg-arrow-gray-50 px-6 py-5">
      <div className="mx-auto grid max-w-[1280px] grid-cols-3 gap-4">
        {vehicles.map((vehicle, index) => (
          <VehicleCard key={vehicle.id} vehicle={vehicle} priority={index < 3} />
        ))}
      </div>
    </section>
  )
}
