"use client"

import { Mic, Sparkles } from "lucide-react"

export function Hero() {
  return (
    <section className="bg-background px-6 pb-4 pt-8">
      <div className="mx-auto max-w-[1280px]">
        <h1 className="text-3xl font-bold tracking-tight text-foreground">FIND YOUR NEXT CAR</h1>
        <p className="mt-0.5 text-sm text-arrow-gray-500">1,784,303 Vehicles Available</p>

        <div className="mt-5 flex items-center gap-3">
          {/* Search bar */}
          <div className="flex flex-1 items-center rounded-full border border-arrow-gray-200 bg-background px-4 py-2.5 shadow-sm">
            <Sparkles className="mr-2 h-4 w-4 text-[#9333ea]" />
            <span className="text-sm text-foreground">SUV under 35k with <strong>low miles</strong></span>
          </div>
          <button className="flex h-10 w-10 items-center justify-center rounded-full border border-arrow-gray-200 text-arrow-gray-400 hover:bg-arrow-gray-50" aria-label="Voice search">
            <Mic className="h-4 w-4" />
          </button>
          <button className="rounded-full bg-arrow-red px-6 py-2.5 text-sm font-semibold text-background hover:bg-[#cc1e24]">
            Search
          </button>
        </div>

        {/* Quick filter chips */}
        <div className="mt-3 flex items-center justify-end gap-2">
          {["Off-road", "Eco-friendly", "High safety rating", "Near me"].map((chip) => (
            <button
              key={chip}
              className="rounded-full border border-arrow-gray-200 px-3 py-1 text-xs text-arrow-gray-600 hover:bg-arrow-gray-50"
            >
              {chip}
            </button>
          ))}
        </div>
      </div>
    </section>
  )
}
