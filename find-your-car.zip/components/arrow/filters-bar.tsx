"use client"

import { X, ChevronDown, SlidersHorizontal } from "lucide-react"

const topFilters = ["SUV", "$30k-45k", "Heated Seats", "Under 50k mi", "Leather Seats", "4 Doors", "2023 or newer"]
const bottomFilters = ["Sunroof", "4WD", "Leather Seats", "Hybrid", "Apple Carplay", "Hands-Free", "LED Highlights", "LED Taillights"]

function FilterTag({ label }: { label: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-arrow-gray-300 bg-background px-2.5 py-1 text-xs text-foreground">
      {label}
      <X className="h-3 w-3 cursor-pointer text-arrow-gray-400 hover:text-foreground" />
    </span>
  )
}

export function FiltersBar() {
  return (
    <div className="border-b border-t border-arrow-gray-200 bg-arrow-gray-50 px-6 py-3">
      <div className="mx-auto max-w-[1280px]">
        <div className="flex items-start gap-4">
          {/* Left: vehicle count and sort */}
          <div className="flex shrink-0 items-center gap-3">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-arrow-red">
              <SlidersHorizontal className="h-4 w-4 text-background" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">247 vehicles found</p>
              <div className="flex items-center gap-1 text-xs text-arrow-gray-500">
                <span>Sort by:</span>
                <button className="flex items-center gap-0.5 font-medium text-foreground">
                  Recommended
                  <ChevronDown className="h-3 w-3" />
                </button>
              </div>
            </div>
          </div>

          {/* Right: filter tags in two rows */}
          <div className="flex flex-1 flex-col items-end gap-1.5">
            <div className="flex flex-wrap items-center justify-end gap-1.5">
              {topFilters.map((filter, i) => (
                <FilterTag key={`top-${filter}-${i}`} label={filter} />
              ))}
            </div>
            <div className="flex flex-wrap items-center justify-end gap-1.5">
              {bottomFilters.map((filter, i) => (
                <FilterTag key={`bottom-${filter}-${i}`} label={filter} />
              ))}
              <button className="rounded-full bg-arrow-gray-800 px-3 py-1 text-xs font-medium text-background hover:bg-arrow-gray-700">
                Reset
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
