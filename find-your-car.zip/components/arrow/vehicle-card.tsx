"use client"

import Image from "next/image"
import { Share2, Heart, MapPin, Shield, CircleCheck, User } from "lucide-react"
import type { Vehicle } from "@/lib/vehicle-data"

function BadgeLabel({ badge }: { badge: Vehicle["badge"] }) {
  if (!badge) return null

  const config = {
    excellent: { label: "Excellent Price", bg: "bg-[#E8F5E9]", text: "text-[#2E7D32]", dot: "bg-[#4CAF50]" },
    priceDrop: { label: "Price Drop", bg: "bg-[#FFF3E0]", text: "text-[#E65100]", dot: "bg-[#FF9800]" },
    lowPrice: { label: "Low Price", bg: "bg-[#FFF9C4]", text: "text-[#F57F17]", dot: "bg-[#FDD835]" },
  }

  const { label, bg, text, dot } = config[badge]

  return (
    <span className={`inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-semibold ${bg} ${text}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${dot}`} />
      {label}
    </span>
  )
}

function MatchBadge({ percent }: { percent: number }) {
  let bg = "bg-arrow-red"
  if (percent >= 90) bg = "bg-[#2E7D32]"
  else if (percent >= 80) bg = "bg-[#43A047]"
  else if (percent >= 70) bg = "bg-[#66BB6A]"
  else if (percent >= 50) bg = "bg-[#FFA726]"

  return (
    <span className={`inline-flex items-center rounded px-2 py-0.5 text-[10px] font-semibold text-background ${bg}`}>
      {percent}% Match
    </span>
  )
}

export function VehicleCard({ vehicle }: { vehicle: Vehicle }) {
  const {
    year, make, model, trim, price, originalPrice, mileage, estMonthly,
    exteriorColor, exteriorColorHex, interiorColor, interiorColorHex,
    matchPercent, badge, dealer, distance, hasWarranty, isInspected, owners, imageUrl
  } = vehicle

  const title = `${year} ${make} ${model}${trim ? `\n${trim}` : ""}`
  const titleLine1 = `${year} ${make} ${model}`
  const titleLine2 = trim || ""

  return (
    <div className="flex flex-col rounded-lg border border-arrow-gray-200 bg-background">
      {/* Image area */}
      <div className="relative px-3 pt-3">
        {/* Badge + actions row */}
        <div className="mb-1 flex items-center justify-between">
          <div>{badge && <BadgeLabel badge={badge} />}</div>
          <div className="flex items-center gap-2">
            <button className="text-arrow-gray-400 hover:text-foreground" aria-label="Share">
              <Share2 className="h-4 w-4" />
            </button>
            <button className="text-arrow-gray-400 hover:text-arrow-red" aria-label="Save">
              <Heart className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div className="relative mx-auto flex h-[140px] items-center justify-center rounded-lg bg-arrow-gray-50">
          <Image
            src={imageUrl}
            alt={`${year} ${make} ${model} ${trim}`}
            fill
            className="object-contain"
            sizes="(max-width: 768px) 100vw, 33vw"
          />
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-1 flex-col px-3 pb-3 pt-2">
        {/* Title + Price */}
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-sm font-bold leading-tight text-foreground">{titleLine1}</p>
            {titleLine2 && <p className="text-sm font-bold leading-tight text-foreground">{titleLine2}</p>}
          </div>
          <div className="text-right">
            {originalPrice && (
              <p className="text-[10px] text-arrow-gray-400 line-through">
                was ${originalPrice.toLocaleString()}
              </p>
            )}
            <p className="text-sm font-bold text-arrow-red">${price.toLocaleString()}</p>
          </div>
        </div>

        {/* Mileage + Est monthly */}
        <div className="mt-1 flex items-center justify-between">
          <span className="flex items-center gap-1 text-[11px] text-arrow-gray-500">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-arrow-gray-400">
              <circle cx="12" cy="12" r="10"/>
              <polyline points="12 6 12 12 16 14"/>
            </svg>
            {mileage.toLocaleString()}mi
          </span>
          <span className="text-[11px] text-arrow-gray-500">Est. ${estMonthly.toLocaleString()}/mo</span>
        </div>

        {/* Separator */}
        <div className="my-2 h-px bg-arrow-gray-100" />

        {/* Exterior */}
        <div className="flex items-center justify-between">
          <span className="text-[11px] text-arrow-gray-500">Exterior:</span>
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-foreground">{exteriorColor}</span>
            <span
              className="h-3.5 w-3.5 rounded-sm border border-arrow-gray-200"
              style={{ backgroundColor: exteriorColorHex }}
            />
          </div>
        </div>

        {/* Interior */}
        <div className="mt-1.5 flex items-center justify-between">
          <span className="text-[11px] text-arrow-gray-500">Interior:</span>
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] text-foreground">{interiorColor}</span>
            <span
              className="h-3.5 w-3.5 rounded-sm border border-arrow-gray-200"
              style={{ backgroundColor: interiorColorHex }}
            />
          </div>
        </div>

        {/* Match + Refine */}
        <div className="mt-2.5 flex items-center justify-between">
          <MatchBadge percent={matchPercent} />
          <a href="#" className="text-[11px] text-foreground underline">Refine your search</a>
        </div>

        {/* Separator */}
        <div className="my-2 h-px bg-arrow-gray-100" />

        {/* Dealer + Distance */}
        <div className="flex items-center justify-between">
          <a href="#" className="text-[11px] text-foreground underline">{dealer}</a>
          <span className="flex items-center gap-1 text-[11px] text-arrow-gray-500">
            <MapPin className="h-3 w-3" />
            {distance}mi
          </span>
        </div>

        {/* Warranty / Inspected / Owner */}
        <div className="mt-1.5 flex items-center gap-3">
          {hasWarranty && (
            <span className="flex items-center gap-1 text-[10px] text-arrow-gray-500">
              <Shield className="h-3 w-3" />
              Warranty
            </span>
          )}
          {isInspected && (
            <span className="flex items-center gap-1 text-[10px] text-arrow-gray-500">
              <CircleCheck className="h-3 w-3" />
              Inspected
            </span>
          )}
          <span className="flex items-center gap-1 text-[10px] text-arrow-gray-500">
            <User className="h-3 w-3" />
            {owners} Owner{owners > 1 ? "s" : ""}
          </span>
        </div>
      </div>
    </div>
  )
}
