"use client"

import { MapPin, Heart } from "lucide-react"

export function Header() {
  return (
    <header className="border-b border-arrow-gray-200 bg-background">
      <div className="mx-auto flex h-14 max-w-[1280px] items-center justify-between px-6">
        {/* Left: Logo + Nav */}
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 rounded bg-arrow-red" />
            <span className="text-sm font-bold tracking-wider text-foreground">ARROW</span>
          </div>
          <nav className="flex items-center gap-6">
            <a href="#" className="text-sm font-medium text-foreground hover:text-arrow-gray-600">Buy</a>
            <a href="#" className="text-sm font-medium text-foreground hover:text-arrow-gray-600">Sell</a>
            <a href="#" className="text-sm font-medium text-foreground hover:text-arrow-gray-600">Finance</a>
            <a href="#" className="text-sm font-medium text-foreground hover:text-arrow-gray-600">Why Arrow</a>
          </nav>
        </div>

        {/* Right: Location, Heart, Profile */}
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-1.5 text-sm text-foreground">
            <MapPin className="h-4 w-4" />
            <span>Buffalo, WV 25033</span>
          </div>
          <button className="text-foreground hover:text-arrow-gray-600" aria-label="Favorites">
            <Heart className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-[#4CAF50] text-xs font-semibold text-background">
              S
            </div>
            <span className="text-sm text-foreground">Sarah...</span>
          </div>
        </div>
      </div>
    </header>
  )
}
