import { Header } from "@/components/arrow/header"
import { Hero } from "@/components/arrow/hero"
import { FiltersBar } from "@/components/arrow/filters-bar"
import { VehicleGrid } from "@/components/arrow/vehicle-grid"
import { Footer } from "@/components/arrow/footer"

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Header />
      <Hero />
      <FiltersBar />
      <VehicleGrid />
      <Footer />
    </div>
  )
}
