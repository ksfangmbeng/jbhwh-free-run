import React from "react";
export default (props) => {
	return (
		<div className="flex flex-col bg-white">
			<div className="self-stretch bg-[#F4F4F4] pt-[18px]">
				<div className="flex items-center self-stretch py-0.5 mb-[30px] mx-20">
					<div className="flex shrink-0 items-center gap-4">
						<img
							src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/y0ft0bqf_expires_30_days.png"} 
							className="w-10 h-10 object-fill"
						/>
						<div className="flex flex-col shrink-0 items-start pb-[1px]">
							<span className="text-black text-lg font-bold" >
								{"ARROW"}
							</span>
						</div>
					</div>
					<div className="flex-1 self-stretch">
					</div>
					<span className="text-[#111111] text-sm mr-[139px]" >
						{"Buy                Sell                Finance                Why Arrow"}
					</span>
					<div className="flex shrink-0 items-center gap-[27px]">
						<div className="flex shrink-0 items-center gap-1.5">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2aidaqmm_expires_30_days.png"} 
								className="w-2.5 h-[13px] object-fill"
							/>
							<span className="text-[#111111] text-sm" >
								{"Buffalo, WV 25033"}
							</span>
						</div>
						<div className="flex shrink-0 items-center gap-4">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/mc0t3zw5_expires_30_days.png"} 
								className="w-10 h-10 object-fill"
							/>
							<div className="flex shrink-0 items-center py-[9px] px-[11px] gap-3 rounded-[100px] border border-solid border-black">
								<div className="flex flex-col shrink-0 items-start bg-[#EB0A1E] py-0.5 px-[7px] rounded-[40px]">
									<span className="text-white text-sm font-bold" >
										{"S"}
									</span>
								</div>
								<span className="text-[#111111] text-sm font-bold" >
									{"Sarah..."}
								</span>
							</div>
						</div>
					</div>
				</div>
				<div className="flex flex-col items-start self-stretch relative mb-[50px]">
					<div className="flex flex-col items-start self-stretch pt-[26px]" 
						style={{
							background: "linear-gradient(180deg, #F4F4F4, #F4F4F400)"
						}}>
						<div className="flex justify-between items-center self-stretch mb-6 mx-20">
							<div className="flex flex-col shrink-0 items-start gap-4">
								<span className="text-[#111111] text-[32px] font-bold" >
									{"Find your next Car"}
								</span>
								<span className="text-black text-[15px] mr-[126px]" >
									{"1,784,503 Vehicles Available"}
								</span>
							</div>
							<div className="flex shrink-0 items-center bg-white py-2 rounded-[100px]">
								<div className="flex shrink-0 items-center ml-5 mr-[466px] gap-2">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yxuwzb5v_expires_30_days.png"} 
										className="w-[19px] h-[19px] object-fill"
									/>
									<span className="text-black text-[15px]" >
										{"SUV under 35k with low miles"}
									</span>
								</div>
								<div className="flex shrink-0 items-center mr-2 gap-[15px]">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/njafymfh_expires_30_days.png"} 
										className="w-2.5 h-4 object-fill"
									/>
									<button className="flex flex-col shrink-0 items-start bg-[#FF0202] text-left py-2.5 px-[23px] rounded-[100px] border-0"
										onClick={()=>alert("Pressed!")}>
										<span className="text-white text-sm font-bold" >
											{"Search"}
										</span>
									</button>
								</div>
							</div>
						</div>
						<div className="flex flex-col items-end self-stretch mb-6">
							<div className="flex items-center mr-20 gap-2">
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Off-road"}
									</span>
								</button>
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Eco-friendly"}
									</span>
								</button>
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"High safety rating"}
									</span>
								</button>
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Near me"}
									</span>
								</button>
							</div>
						</div>
						<div className="self-stretch bg-black h-[1px] mb-8">
						</div>
						<div className="flex justify-between items-start self-stretch max-w-[1228px] mb-1.5 ml-[132px] mr-20">
							<span className="text-[#111111] text-base font-bold mt-[13px]" >
								{"247 vehicles found"}
							</span>
							<div className="flex shrink-0 items-center gap-1">
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"SUV"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/65xsf3yl_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-[5px] rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"$30k-40k"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/z3fmgl5m_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Heated Seats"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/hru2pv15_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Under 50k mi"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/19c6skcc_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-[7px] rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Leather Seats"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/kbjj1saq_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"4 Doors"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/mkmjhkpq_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"2023 or newer"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6i47zfrf_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
							</div>
						</div>
						<img
							src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/qizssit5_expires_30_days.png"} 
							className="w-[11px] h-1.5 ml-[276px] object-fill"
						/>
					</div>
					<button className="flex flex-col items-start bg-[#FF0202] text-left absolute bottom-[-5px] left-20 p-3 rounded-[100px] border-0"
						onClick={()=>alert("Pressed!")}>
						<img
							src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/lfst08a2_expires_30_days.png"} 
							className="w-4 h-4 object-fill"
						/>
					</button>
					<span className="text-[#121212] text-xs font-bold absolute bottom-[-4px] left-[133px]" >
						{"Sort by: Recommended"}
					</span>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] left-[505px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"Sunroof"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/12hizwpf_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] left-[587px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-[11px]">
							<span className="text-black text-xs" >
								{"4WD"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/sb6xgmed_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<div className="flex flex-col items-center self-stretch absolute bottom-[-18px] right-0 left-0">
						<button className="flex items-center bg-transparent text-left py-2.5 px-2 gap-[11px] rounded-[100px] border border-solid border-[#0000001A]"
							onClick={()=>alert("Pressed!")}>
							<span className="text-black text-xs" >
								{"Leather Seats"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/rvegecti_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</button>
					</div>
					<div className="flex flex-col items-center self-stretch absolute bottom-[-18px] right-0 left-0">
						<button className="flex items-center bg-transparent text-left py-2.5 px-2 gap-[11px] rounded-[100px] border border-solid border-[#0000001A]"
							onClick={()=>alert("Pressed!")}>
							<span className="text-black text-xs" >
								{"Hybrid"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/wbmujm3t_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</button>
					</div>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[485px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"Apple Carplay"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/tzxe36y6_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[382px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"Hands-Free"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/1xpnwy6t_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[261px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"LED Highlights"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/unkjugza_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[148px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-[11px]">
							<span className="text-black text-xs" >
								{"LED Taillights"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ajcqidgo_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-black text-left absolute bottom-[-18px] right-20 py-2.5 px-4 rounded-[100px] border-0"
						onClick={()=>alert("Pressed!")}>
						<span className="text-white text-xs" >
							{"Reset"}
						</span>
					</button>
				</div>
				<div className="flex flex-col self-stretch mb-20 mx-20 gap-4">
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[84px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9zm90bct_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-[11px] mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#111111] text-base font-bold w-[151px]" >
											{"2023 Toyota Corolla  Cross"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-0.5 pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/eqv3a2g3_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"18,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-[13px]">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Red"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2m9bjbnh_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/8nrggb8c_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"99% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/rr92tgeg_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6w4yp3hy_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fqazetbk_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9q0i1nxq_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/tz9pyp2p_expires_30_days.png"} 
											className="w-3.5 h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Excellent Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fnlj2539_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-[11px] mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2022 Toyota RAV4 Hybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-0.5 pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/dlafc3x6_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"24,600mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-[13px]">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic White"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fezvxlhm_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/1r02vru9_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"98% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/v8gu0qbx_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ftr7njgw_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6kpw15sd_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/rtppt8va_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#0066CC] text-left py-[5px] px-[7px] gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/aqacow6e_expires_30_days.png"} 
											className="w-[13px] h-[13px] rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Price Drop"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/wi5kv553_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-[11px] mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2023 Toyota RAV4\nHybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start py-0.5 gap-2">
										<span className="text-[#58595B] text-xs ml-[23px]" >
											{"was $34,900"}
										</span>
										<div className="flex flex-col items-start pl-[17px] pr-0.5">
											<span className="text-[#EB0D1C] text-xl font-bold" >
												{"$33,250"}
											</span>
										</div>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/3a6lfycx_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"21,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-[13px]">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/j5makqwt_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/5bqk7wk8_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"78% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ekakuw60_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/od0gpz45_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/0zhajl04_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/rgjjkwuc_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="bg-[#0E5B32] w-[90px] h-6 rounded">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2jm7u7il_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2024 Toyota RAV4 Hybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$29,990"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/rhx0fvi3_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"24,500mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic White"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/3kinqg9z_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/t1b4g7i4_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"85% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/xxcli07z_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/30a6tdh9_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/odo7326w_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/dtink68k_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/iypgxorj_expires_30_days.png"} 
											className="w-3.5 h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Excellent Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/qrumf29h_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-44" >
											{"2022 Toyota Yaris Cross\nHybrid Active"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$30,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/e42jzqyf_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"16,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/nmepjulq_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/mdy9ft72_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"84% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/noml23bf_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/rwa3h45p_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yryjk5kx_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2rqmrl6z_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[84px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/dkmuj4oa_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[151px]" >
											{"2023 Toyota Corolla  Cross"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/u2d4880h_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"18,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic White"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9imgp6sx_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/akevk6zi_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"81% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/xzrb07fj_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/077ihtkk_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ay203i31_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/i32go69y_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="bg-[#12B45D] w-[87px] h-6 rounded">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/n42ishin_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2024 Toyota RAV4\nHybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$33,500"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fkuqnxar_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"5,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Ocean Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9bnowz7z_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yy7zfy4r_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"97% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/5cjsgsco_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/f4c0352r_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/goqx4iqa_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2aiofx13_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[107px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/abz8j1t5_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[140px]" >
											{"2020 Toyota Venza\nLimited Edition"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$32,000"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/w8bwu24a_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"9,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Graphite"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/kiythbyk_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/dazkhxvq_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"74% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/jb255034_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/cbwfbup4_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/3h4vkfek_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/aedhu1rb_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yn657pgs_expires_30_days.png"} 
											className="w-[18px] h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Low Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/0mcxrimc_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-44" >
											{"2022 Toyota Yaris Cross\nHybrid Active"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$24,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/3drw659r_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"11,050mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Sunrise Yellow"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/jsjxh8yu_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/jdnd2app_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"72% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/pdrjix7z_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9r81r8yv_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/s9wpszwd_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/mt5s10lb_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/loyqzd8i_expires_30_days.png"} 
											className="w-[18px] h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Low Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/hjklg2q6_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2025 Toyota RAV4\nLimited Edition"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$30,900"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/wlc42tbn_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"15,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Gray"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/q53ig8id_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/424dt7rb_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"55% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/kc2kkme1_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fgwit9xf_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/b9zjvo3y_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/vq9jqjj6_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#0066CC] text-left py-[5px] px-[7px] gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/25hdxqyn_expires_30_days.png"} 
											className="w-[13px] h-[13px] rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Price Drop"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/na3395ol_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[197px]" >
											{"2020 Toyota Corolla Cross\nLimited Edition"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start py-[1px] gap-[7px]">
										<span className="text-[#58595B] text-xs ml-[23px]" >
											{"was $35,900"}
										</span>
										<div className="flex flex-col items-start pl-[19px] pr-[3px]">
											<span className="text-[#EB0D1C] text-xl font-bold" >
												{"$31,250"}
											</span>
										</div>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/npmj3lse_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"17,200mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Pastel Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2vkwnxpy_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6m358r13_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"98% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/7kc5o0ui_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/c6e7wx6m_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9dx9vjuy_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/4erzsizz_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[84px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6z4n6422_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[151px]" >
											{"2023 Toyota Corolla  Cross"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/5ppjuz86_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"18,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Red"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/nia1au9j_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/3vm8buhn_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"99% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/blcm1449_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/7abyi3uq_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yvptsqdx_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/8k6vzvrt_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="self-stretch bg-[#1A1A1A] py-[54px]">
					<div className="flex items-start self-stretch max-w-[1189px] mb-[65px] ml-20 mr-[171px]">
						<div className="flex-1 mr-[54px]">
							<div className="flex flex-col items-start self-stretch pb-[1px] mb-4">
								<span className="text-[#EB0A1E] text-2xl font-bold" >
									{"Arrow"}
								</span>
							</div>
							<div className="flex flex-col items-start self-stretch pt-[1px] mb-[15px]">
								<span className="text-[#99A1AE] text-sm w-[179px]" >
									{"Your trusted partner for quality pre-owned vehicles."}
								</span>
							</div>
							<div className="flex items-center self-stretch gap-3">
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/wewrmat2_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/4snbgs8e_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6ubd070b_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9thnfaiq_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
							</div>
						</div>
						<div className="flex flex-1 flex-col mr-[55px] gap-4">
							<div className="flex flex-col items-start self-stretch">
								<span className="text-white text-lg font-bold" >
									{"Shop"}
								</span>
							</div>
							<div className="self-stretch pb-[33px]">
								<div className="flex flex-col items-start self-stretch py-[3px] mb-2">
									<span className="text-[#99A1AE] text-sm" >
										{"Buy a Car"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Sell Your Car"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Finance Options"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Trade-In Value"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex flex-1 flex-col mr-[54px] gap-4">
							<div className="flex flex-col items-start self-stretch">
								<span className="text-white text-lg font-bold" >
									{"Support"}
								</span>
							</div>
							<div className="self-stretch pb-[1px]">
								<div className="flex flex-col items-start self-stretch py-[3px] mb-2">
									<span className="text-[#99A1AE] text-sm" >
										{"Contact Us"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"FAQs"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Financing Help"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Returns & Exchanges"}
									</span>
								</div>
								<div className="self-stretch h-[23px]">
								</div>
							</div>
						</div>
						<div className="flex flex-1 flex-col mr-[55px] gap-4">
							<div className="flex flex-col items-start self-stretch">
								<span className="text-white text-lg font-bold" >
									{"Company"}
								</span>
							</div>
							<div className="self-stretch pb-[1px]">
								<div className="flex flex-col items-start self-stretch py-[3px] mb-2">
									<span className="text-[#99A1AE] text-sm" >
										{"About Arrow"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Press"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Partnerships"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Locations"}
									</span>
								</div>
								<div className="self-stretch h-[23px] py-[3px]">
								</div>
							</div>
						</div>
						<div className="flex flex-col shrink-0 items-start">
							<span className="text-white text-lg font-bold mb-5 mr-[58px]" >
								{"Legal"}
							</span>
							<div className="flex flex-col items-start mb-4 mr-[18px]">
								<span className="text-[#99A1AE] text-sm" >
									{"Privacy Policy"}
								</span>
							</div>
							<div className="flex flex-col items-start mb-4">
								<span className="text-[#99A1AE] text-sm" >
									{"Terms of Service"}
								</span>
							</div>
							<div className="flex flex-col items-start mb-4 mr-[18px]">
								<span className="text-[#99A1AE] text-sm" >
									{"Cookie Policy"}
								</span>
							</div>
							<div className="flex flex-col items-start mb-4 mr-6">
								<span className="text-[#99A1AE] text-sm" >
									{"Accessibility"}
								</span>
							</div>
							<div className="flex flex-col items-start mr-[51px]">
								<span className="text-[#99A1AE] text-sm" >
									{"Sitemap"}
								</span>
							</div>
						</div>
					</div>
					<div className="flex justify-between items-center self-stretch mb-[45px] mx-20">
						<div className="flex shrink-0 items-center gap-[11px]">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6zk7tiwl_expires_30_days.png"} 
								className="w-5 h-5 object-fill"
							/>
							<div className="flex flex-col shrink-0 items-start">
								<div className="flex flex-col items-start pr-[101px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Call Us"}
									</span>
								</div>
								<div className="flex flex-col items-start pr-[21px]">
									<span className="text-white text-base font-bold" >
										{"1-800-GO-Arrow"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex shrink-0 items-center gap-[11px]">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/xdtemhr4_expires_30_days.png"} 
								className="w-5 h-5 object-fill"
							/>
							<div className="flex flex-col shrink-0 items-start">
								<div className="flex flex-col items-start pr-[104px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Email Us"}
									</span>
								</div>
								<div className="flex flex-col items-start">
									<span className="text-white text-base font-bold" >
										{"support@arrow.com"}
									</span>
								</div>
							</div>
						</div>
						<div className="w-[178px] h-[43px]">
						</div>
					</div>
					<div className="flex justify-between items-center self-stretch mx-20">
						<div className="flex flex-col shrink-0 items-start pt-[1px]">
							<span className="text-[#99A1AE] text-sm" >
								{"© 2026 Toyota Financial Services. All rights reserved."}
							</span>
						</div>
						<div className="flex flex-col shrink-0 items-start pt-[1px]">
							<span className="text-[#99A1AE] text-sm" >
								{"Project ARROW (331) • R1 Launch: March 31, 2026"}
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}