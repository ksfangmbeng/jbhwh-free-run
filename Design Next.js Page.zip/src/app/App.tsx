import { useEffect, useState } from "react";
import SearchPageFull from "../imports/SearchPageFull";
import MobileSearch from "../imports/MobileSearch";

export default function App() {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    // Check on mount
    checkMobile();

    // Add event listener for window resize
    window.addEventListener("resize", checkMobile);

    // Cleanup
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  return isMobile ? <MobileSearch /> : <SearchPageFull />;
}
