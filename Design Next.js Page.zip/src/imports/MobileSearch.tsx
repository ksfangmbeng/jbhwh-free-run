import svgPaths from "./svg-zrlnikdt2u";
import imgImage990 from "figma:asset/fe6be21663a63f10771602fdece38074f80f8573.png";
import imgImage980 from "figma:asset/b6698f7145da88172272ca97c2cb2bf7bba3d1af.png";
import imgImage981 from "figma:asset/2a7c58bfbb1822785643b5307123a107bf86c9e9.png";
import imgImage982 from "figma:asset/f0956ff12948219a4c59e52d07d0cc9e57755bf3.png";
import imgImage991 from "figma:asset/f084c73296c7d07a55e5634fba59677b6bc1576a.png";
import imgImage983 from "figma:asset/d6835baa66fd349c7f94b548b0c9d1c3742001ff.png";
import imgImage979 from "figma:asset/a1f217c3c2fe117071c541686d84a93826c515d7.png";
import { imgRectangle14593 } from "./svg-h7p8l";

function Container1() {
  return (
    <div className="h-[31.997px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Bold',sans-serif] leading-[32px] left-0 not-italic text-[#eb0a1e] text-[40px] top-[-0.33px] tracking-[0.0703px]">Arrow</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[21px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[1.01px] tracking-[-0.1504px] w-[350px] whitespace-pre-wrap">Your trusted partner for quality pre-owned vehicles.</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.pd654152} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="h-[56px] relative rounded-[8px] shrink-0 w-[77px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p25eafc80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="h-[56px] relative rounded-[8px] shrink-0 w-[75px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[24px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 24 24">
        <g id="Icon">
          <path d={svgPaths.p19f4f2} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p13677b00} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d="M17.5 6.5H17.51" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="h-[56px] relative rounded-[8px] shrink-0 w-[78px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[32px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Icon">
          <path d={svgPaths.p18c72a00} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
          <path d={svgPaths.p127ff880} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="h-[56px] relative rounded-[8px] shrink-0 w-[77px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Container2() {
  return (
    <div className="content-stretch flex gap-[12px] items-start relative shrink-0 w-full" data-name="Container">
      <Button />
      <Button1 />
      <Button2 />
      <Button3 />
    </div>
  );
}

function Container() {
  return (
    <div className="content-stretch flex flex-col gap-[15.998px] items-start relative shrink-0 w-full" data-name="Container">
      <Container1 />
      <Paragraph />
      <Container2 />
    </div>
  );
}

function Section() {
  return (
    <div className="content-stretch flex items-center justify-between pb-[24px] relative shrink-0 w-full" data-name="Section">
      <div aria-hidden="true" className="absolute border-[#58595b] border-b border-solid inset-0 pointer-events-none" />
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-white">Shop</p>
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="chevron-down">
        <div className="absolute bottom-[37.5%] left-1/4 right-1/4 top-[37.5%]" data-name="Icon">
          <div className="absolute inset-[-16.67%_-8.33%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 8">
              <path d="M1 1L7 7L13 1" id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section1() {
  return (
    <div className="content-stretch flex items-center justify-between py-[24px] relative shrink-0 w-full" data-name="Section">
      <div aria-hidden="true" className="absolute border-[#58595b] border-b border-solid inset-0 pointer-events-none" />
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-white">Support</p>
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="chevron-down">
        <div className="absolute bottom-[37.5%] left-1/4 right-1/4 top-[37.5%]" data-name="Icon">
          <div className="absolute inset-[-16.67%_-8.33%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 8">
              <path d="M1 1L7 7L13 1" id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section2() {
  return (
    <div className="content-stretch flex items-center justify-between py-[24px] relative shrink-0 w-full" data-name="Section">
      <div aria-hidden="true" className="absolute border-[#58595b] border-b border-solid inset-0 pointer-events-none" />
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-white">Company</p>
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="chevron-down">
        <div className="absolute bottom-[37.5%] left-1/4 right-1/4 top-[37.5%]" data-name="Icon">
          <div className="absolute inset-[-16.67%_-8.33%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 8">
              <path d="M1 1L7 7L13 1" id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Section3() {
  return (
    <div className="content-stretch flex items-center justify-between py-[24px] relative shrink-0 w-full" data-name="Section">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[16px] text-white">Legal</p>
      <div className="overflow-clip relative shrink-0 size-[24px]" data-name="chevron-down">
        <div className="absolute bottom-[37.5%] left-1/4 right-1/4 top-[37.5%]" data-name="Icon">
          <div className="absolute inset-[-16.67%_-8.33%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 8">
              <path d="M1 1L7 7L13 1" id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0 w-full" data-name="Container">
      <Section />
      <Section1 />
      <Section2 />
      <Section3 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_3153)" id="Icon">
          <path d={svgPaths.pd3dc00} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_3153">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container8() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">Call Us</p>
    </div>
  );
}

function Container7() {
  return (
    <div className="relative shrink-0 w-[100px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative w-full">
        <Container8 />
      </div>
    </div>
  );
}

function Container6() {
  return (
    <div className="content-stretch flex gap-[11.997px] h-[43.993px] items-center relative shrink-0" data-name="Container">
      <Icon4 />
      <Container7 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.pc999300} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p26573700} id="Vector_2" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">Email Us</p>
    </div>
  );
}

function Container10() {
  return (
    <div className="relative shrink-0 w-[100px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative w-full">
        <Container11 />
      </div>
    </div>
  );
}

function Container9() {
  return (
    <div className="content-stretch flex gap-[11.997px] h-[43.993px] items-center relative shrink-0" data-name="Container">
      <Icon5 />
      <Container10 />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p21963d80} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p28175700} id="Vector_2" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container14() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">Find a Location</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="relative shrink-0 w-[100px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative w-full">
        <Container14 />
      </div>
    </div>
  );
}

function Container12() {
  return (
    <div className="content-stretch flex gap-[11.997px] h-[43.993px] items-center relative shrink-0" data-name="Container">
      <Icon6 />
      <Container13 />
    </div>
  );
}

function Container5() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-full" data-name="Container">
      <Container6 />
      <Container9 />
      <Container12 />
    </div>
  );
}

function Container4() {
  return (
    <div className="content-stretch flex flex-col items-start pt-[32.552px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#58595b] border-solid border-t-[0.556px] inset-0 pointer-events-none" />
      <Container5 />
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[20px] relative shrink-0 w-[345.556px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[12px] top-[0.67px] tracking-[-0.1504px]">© 2026 Toyota Financial Services. All rights reserved.</p>
      </div>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[20px] relative shrink-0 w-[327.005px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[12px] top-[0.67px] tracking-[-0.1504px]">Project ARROW (331) • R1 Launch: March 31, 2026</p>
      </div>
    </div>
  );
}

function Container15() {
  return (
    <div className="content-stretch flex flex-col h-[65px] items-start justify-between pt-[24.556px] relative shrink-0 w-full" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#58595b] border-solid border-t-[0.556px] inset-0 pointer-events-none" />
      <Container16 />
      <Container17 />
    </div>
  );
}

function FooterM() {
  return (
    <div className="absolute bg-[#1a1a1a] bottom-[0.46px] content-stretch flex flex-col gap-[32px] items-start left-0 px-[24px] py-[50px] w-[390px]" data-name="Footer_M">
      <Container />
      <Container3 />
      <Container4 />
      <Container15 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#111] text-[16px] uppercase">ARROW</p>
    </div>
  );
}

function Logo() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0" data-name="Logo">
      <div className="bg-[#eb0a1e] shrink-0 size-[40px]" data-name="Logo" />
      <Frame />
    </div>
  );
}

function Wishlist() {
  return (
    <div className="h-[40px] relative shrink-0 w-[42px]" data-name="wishlist">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="wishlist">
          <g id="Ellipse 1">
            <circle cx="20" cy="20" fill="var(--fill-0, white)" r="20" />
            <circle cx="20" cy="20" r="19.5" stroke="var(--stroke-0, #58595B)" strokeOpacity="0.3" />
          </g>
          <path d={svgPaths.p529a00} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame41() {
  return (
    <div className="bg-[#eb0a1e] col-1 content-stretch flex flex-col items-center justify-center ml-[10px] mt-[10px] p-[10px] relative rounded-[40px] row-1 size-[20px]">
      <div className="-translate-x-1/2 -translate-y-full absolute flex flex-col font-['Toyota_Type:Semibold',sans-serif] h-[14px] justify-end leading-[0] left-[calc(50%+0.2px)] not-italic overflow-hidden text-[14px] text-center text-ellipsis text-white top-[calc(50%+6px)] w-[4px] whitespace-nowrap">
        <p className="leading-[15px] overflow-hidden">S</p>
      </div>
    </div>
  );
}

function Wishlist1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="wishlist">
      <div className="col-1 ml-0 mt-0 relative row-1 size-[40px]">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
          <g id="Ellipse 1">
            <circle cx="20" cy="20" fill="var(--fill-0, white)" r="20" />
            <circle cx="20" cy="20" r="19.5" stroke="var(--stroke-0, #58595B)" strokeOpacity="0.3" />
          </g>
        </svg>
      </div>
      <Frame41 />
    </div>
  );
}

function Wishlist2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="wishlist">
      <div className="col-1 ml-0 mt-0 relative row-1 size-[40px]">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
          <g id="Ellipse 1">
            <circle cx="20" cy="20" fill="var(--fill-0, white)" r="20" />
            <circle cx="20" cy="20" r="19.5" stroke="var(--stroke-0, #58595B)" strokeOpacity="0.3" />
          </g>
        </svg>
      </div>
      <div className="col-1 ml-[11px] mt-[11px] overflow-clip relative row-1 size-[18px]" data-name="menu-04">
        <div className="absolute bottom-1/4 left-[12.5%] right-[12.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-8.33%_-5.56%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 10.5">
              <path d={svgPaths.p2d690120} id="Icon" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function CtAs() {
  return (
    <div className="content-stretch flex gap-[8px] h-[40px] items-center justify-end relative shrink-0" data-name="CTAs">
      <Wishlist />
      <Wishlist1 />
      <Wishlist2 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute inset-[32.92%_90.14%_32.92%_4.44%]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 18.5254 19.127">
        <g id="Group 1000004550">
          <path d={svgPaths.p1dfa7a00} fill="var(--fill-0, #EB0D1C)" id="Vector" />
          <path d={svgPaths.p31a9c400} fill="var(--fill-0, #EB0D1C)" id="Vector_2" />
          <path d={svgPaths.p27137772} fill="var(--fill-0, #EB0D1C)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Mic() {
  return (
    <div className="h-[20.473px] relative shrink-0 w-[13.001px]" data-name="mic">
      <div className="absolute inset-[-2.93%_-4.62%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.2007 21.6728">
          <g id="mic">
            <path d={svgPaths.p15eb9140} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d={svgPaths.p1a495500} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d="M7.10195 17.3505V21.0728" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d="M3.38516 21.0693H10.8141" id="Vector_4" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="-translate-y-1/2 absolute content-stretch flex h-[45.714px] items-center left-[261px] top-[calc(50%-0.14px)]">
      <Mic />
    </div>
  );
}

function Mic1() {
  return (
    <div className="h-[16px] relative shrink-0 w-[10.182px]" data-name="mic">
      <div className="absolute inset-[-3.75%_-5.89%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.3818 17.2">
          <g id="mic">
            <path d={svgPaths.p1733b100} id="Vector" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d={svgPaths.p3b194780} id="Vector_2" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d="M5.6918 13.6898V16.5989" id="Vector_3" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d="M2.78164 16.6H8.59979" id="Vector_4" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Cta() {
  return (
    <div className="relative shrink-0 size-[40px]" data-name="CTA">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="CTA">
          <rect fill="var(--fill-0, #EB0A1E)" height="40" id="Rectangle 4" rx="20" width="40" />
          <path d={svgPaths.p198aa280} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
        </g>
      </svg>
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <Cta />
    </div>
  );
}

function Frame86() {
  return (
    <div className="-translate-y-1/2 absolute content-stretch flex gap-[12px] items-center right-[10.82px] top-1/2">
      <Mic1 />
      <Frame21 />
    </div>
  );
}

function Search() {
  return (
    <div className="bg-white h-[56px] relative rounded-[100px] shrink-0 w-[342px]" data-name="Search">
      <div aria-hidden="true" className="absolute border border-[rgba(88,89,91,0.3)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] h-[21px] leading-[0] left-[43.17px] not-italic text-[#121212] text-[0px] text-[14px] top-[calc(50%-10px)] w-[237px] whitespace-pre-wrap">
        <span className="leading-[18px]">SUVs under $35k with</span>
        <span className="leading-[18px]">{` `}</span>
        <span className="font-['Toyota_Type:Bold',sans-serif] leading-[18px]">low miles</span>
      </p>
      <Group9 />
      <Frame22 />
      <Frame86 />
    </div>
  );
}

function Frame128() {
  return (
    <div className="bg-white content-stretch flex items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Off-road</p>
    </div>
  );
}

function Frame129() {
  return (
    <div className="bg-white content-stretch flex items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Eco-friendly</p>
    </div>
  );
}

function Frame126() {
  return (
    <div className="bg-white content-stretch flex items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">High safety rating</p>
    </div>
  );
}

function Frame121() {
  return (
    <div className="bg-white content-stretch flex items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Near me</p>
    </div>
  );
}

function Frame130() {
  return (
    <div className="bg-white content-stretch flex items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">High safety rating</p>
    </div>
  );
}

function Frame127() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0 w-[342px]">
      <Frame128 />
      <Frame129 />
      <Frame126 />
      <Frame121 />
      <Frame130 />
    </div>
  );
}

function Frame169() {
  return (
    <div className="content-stretch flex items-start relative shrink-0 w-[342px]">
      <Frame127 />
    </div>
  );
}

function Filters() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Filters">
      <div className="bg-[#ff0202] col-1 ml-0 mt-0 rounded-[100px] row-1 size-[40px]" />
      <div className="col-1 ml-[12px] mt-[12px] overflow-clip relative row-1 size-[16px]" data-name="filter-lines">
        <div className="absolute bottom-1/4 left-[12.5%] right-[12.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-12.5%_-8.33%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 10">
              <path d="M3 5H11M1 1H13M5 9H9" id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
        <div className="absolute bottom-1/4 left-[12.5%] right-[12.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-6.25%_-4.17%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 9">
              <path d={svgPaths.pf480500} id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Cta1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="CTA">
      <p className="col-1 font-['Toyota_Type:Semibold',sans-serif] leading-[normal] ml-0 mt-0 not-italic relative row-1 text-[#121212] text-[12px]">Sort by: Recommended</p>
      <div className="col-1 h-[6.504px] ml-[143.09px] mt-[1.75px] relative row-1 w-[11.504px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 11.5039 6.50377">
          <path d={svgPaths.p12bd8c80} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0 w-[342px]">
      <Filters />
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#111] text-[12px] w-[109px] whitespace-pre-wrap">247 vehicles found</p>
      <div className="bg-[rgba(88,89,91,0.4)] h-[16px] shrink-0 w-px" />
      <Cta1 />
    </div>
  );
}

function Frame107() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">$30k-40k</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame109() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Heated Seats</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="bg-black content-stretch flex gap-[4px] items-center px-[16px] py-[10px] relative rounded-[100px] shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-center text-white">{`Reset  `}</p>
    </div>
  );
}

function Frame105() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center relative shrink-0 w-full">
      <Frame107 />
      <Frame109 />
      <Frame2 />
    </div>
  );
}

function Frame122() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[11px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">5 Doors</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame125() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[11px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">4WD</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame123() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[11px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Leather Seats</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame124() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[11px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">SUV</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame131() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center relative shrink-0 w-full">
      <Frame122 />
      <Frame125 />
      <Frame123 />
      <Frame124 />
    </div>
  );
}

function Frame119() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[11px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Hybrid</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame133() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[11px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Sunroof</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame134() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[11px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Hands-Free</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame132() {
  return (
    <div className="content-stretch flex gap-[4px] items-center justify-center relative shrink-0 w-full">
      <Frame119 />
      <Frame133 />
      <Frame134 />
    </div>
  );
}

function Frame170() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-start relative shrink-0 w-[342px]">
      <Frame105 />
      <Frame131 />
      <Frame132 />
    </div>
  );
}

function Frame175() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[24px] items-center left-0 top-[104px] w-[390px]">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[56px] min-w-full not-italic relative shrink-0 text-[#111] text-[24px] text-center tracking-[-0.4492px] uppercase w-[min-content] whitespace-pre-wrap">Find your next Car</p>
      <p className="capitalize font-['Toyota_Type:Regular',sans-serif] leading-[22px] min-w-full not-italic relative shrink-0 text-[#111] text-[14px] text-center w-[min-content] whitespace-pre-wrap">1,784,503 Vehicles Available</p>
      <Search />
      <Frame169 />
      <div className="bg-black h-px opacity-10 shrink-0 w-[342px]" />
      <Frame1 />
      <Frame170 />
    </div>
  );
}

function ImageContainer() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[229px] left-[calc(50%+8px)] top-[calc(50%+5.5px)] w-[408px]" data-name="image 990">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage990} />
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[197px] left-[calc(50%-1px)] top-[calc(50%+4.5px)] w-[350px]" data-name="image 979" />
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px]">
        {`2023 Toyota Corolla `}
        <br aria-hidden="true" />
        Cross
      </p>
    </div>
  );
}

function Frame211() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$33,250</p>
    </div>
  );
}

function Frame42() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame211 />
    </div>
  );
}

function Frame51() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame3 />
      <Frame42 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">18,000mi</p>
    </div>
  );
}

function Frame52() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame9 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame238() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame51 />
        <Frame52 />
      </div>
    </div>
  );
}

function MaskGroup() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#2e0507] from-[33.333%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#ff3b42]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame44() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Red</p>
      <MaskGroup />
    </div>
  );
}

function Frame46() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame44 />
    </div>
  );
}

function Frame45() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame47() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame45 />
    </div>
  );
}

function Cta2() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame239() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta2 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame48() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group10() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame53() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame48 />
      <Group10 />
    </div>
  );
}

function Frame230() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame231() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame229() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame54() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame230 />
          <Frame231 />
          <Frame229 />
        </div>
      </div>
    </div>
  );
}

function Frame50() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame238 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame46 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame47 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame239 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame53 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame54 />
    </div>
  );
}

function PriceDropBadge() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame176() {
  return (
    <div className="content-stretch flex items-center opacity-0 relative shrink-0">
      <PriceDropBadge />
    </div>
  );
}

function Frame204() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame205() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame172() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame204 />
      <Frame205 />
    </div>
  );
}

function Frame171() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame176 />
      <Frame172 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame55() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame23 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame24 />
        </div>
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 1">
      <ImageContainer />
      <Frame50 />
      <Frame171 />
      <Frame55 />
    </div>
  );
}

function ImageContainer1() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[229px] left-[calc(50%+8px)] top-[calc(50%+5.5px)] w-[408px]" data-name="image 990">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage990} />
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2022 Toyota RAV4</p>
        <p>Hybrid</p>
      </div>
    </div>
  );
}

function Frame212() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$31,250</p>
    </div>
  );
}

function Frame43() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame212 />
    </div>
  );
}

function Frame57() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame4 />
      <Frame43 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">24,600mi</p>
    </div>
  );
}

function Frame58() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame10 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame240() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame57 />
        <Frame58 />
      </div>
    </div>
  );
}

function MaskGroup1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#f1f1f1] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#e9e9e9] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame59() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic White</p>
      <MaskGroup1 />
    </div>
  );
}

function Frame49() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame59 />
    </div>
  );
}

function Frame61() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame60() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame61 />
    </div>
  );
}

function Cta3() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame241() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta3 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame63() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group11() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group1 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame62() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame63 />
      <Group11 />
    </div>
  );
}

function Frame232() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame233() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame234() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame64() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame232 />
          <Frame233 />
          <Frame234 />
        </div>
      </div>
    </div>
  );
}

function Frame56() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame240 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame49 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame60 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame241 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame62 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame64 />
    </div>
  );
}

function BestDealBadge() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame178() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <BestDealBadge />
    </div>
  );
}

function Frame177() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <Frame178 />
    </div>
  );
}

function Frame206() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame207() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame174() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame206 />
      <Frame207 />
    </div>
  );
}

function Frame173() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame177 />
      <Frame174 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots1() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame26() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame65() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame25 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots1 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame26 />
        </div>
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 2">
      <ImageContainer1 />
      <Frame56 />
      <Frame173 />
      <Frame65 />
    </div>
  );
}

function ImageContainer2() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[163px] left-[calc(50%-0.5px)] top-[calc(50%+19.5px)] w-[317px]" data-name="image 980">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-[-26.48%] max-w-none top-0 w-[147.55%]" src={imgImage980} />
        </div>
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2023 Toyota RAV4</p>
        <p>Hybrid</p>
      </div>
    </div>
  );
}

function Frame213() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$33,250</p>
    </div>
  );
}

function Frame68() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame213 />
    </div>
  );
}

function Frame67() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame5 />
      <Frame68 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">21,000mi</p>
    </div>
  );
}

function Frame69() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame11 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame242() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame67 />
        <Frame69 />
      </div>
    </div>
  );
}

function MaskGroup2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#155681] from-[39.583%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#5ab2ff]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame71() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Blue</p>
      <MaskGroup2 />
    </div>
  );
}

function Frame70() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame71 />
    </div>
  );
}

function Frame73() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame72() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame73 />
    </div>
  );
}

function Cta4() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame243() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta4 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame75() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group12() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group2 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame74() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame75 />
      <Group12 />
    </div>
  );
}

function Frame235() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame236() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame237() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame76() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame235 />
          <Frame236 />
          <Frame237 />
        </div>
      </div>
    </div>
  );
}

function Frame66() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame242 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame70 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame72 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame243 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame74 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame76 />
    </div>
  );
}

function PriceDropBadge1() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame180() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <PriceDropBadge1 />
    </div>
  );
}

function Frame208() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame209() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame181() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame208 />
      <Frame209 />
    </div>
  );
}

function Frame179() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame180 />
      <Frame181 />
    </div>
  );
}

function Frame27() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots2() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame28() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame77() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame27 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots2 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame28 />
        </div>
      </div>
    </div>
  );
}

function Card2() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 3">
      <ImageContainer2 />
      <Frame66 />
      <Frame179 />
      <Frame77 />
    </div>
  );
}

function ImageContainer3() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[229px] left-[calc(50%+8px)] top-[calc(50%+5.5px)] w-[408px]" data-name="image 990">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage990} />
      </div>
      <div className="-translate-x-1/2 absolute h-[280px] left-[calc(50%-17.5px)] rounded-tl-[8px] rounded-tr-[8px] top-[-9px] w-[413px]" data-name="image 931" />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2024 Toyota RAV4</p>
        <p>Hybrid</p>
      </div>
    </div>
  );
}

function Frame214() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$29,990</p>
    </div>
  );
}

function Frame80() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame214 />
    </div>
  );
}

function Frame79() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame6 />
      <Frame80 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">24,600mi</p>
    </div>
  );
}

function Frame81() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame12 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame244() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame79 />
        <Frame81 />
      </div>
    </div>
  );
}

function MaskGroup3() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#f1f1f1] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#e9e9e9] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame83() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic White</p>
      <MaskGroup3 />
    </div>
  );
}

function Frame82() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame83 />
    </div>
  );
}

function Frame85() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame84() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame85 />
    </div>
  );
}

function Cta5() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame245() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta5 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame88() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group13() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group3 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame87() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame88 />
      <Group13 />
    </div>
  );
}

function Frame246() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame247() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame248() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame89() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame246 />
          <Frame247 />
          <Frame248 />
        </div>
      </div>
    </div>
  );
}

function Frame78() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame244 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame82 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame84 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame245 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame87 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame89 />
    </div>
  );
}

function Frame183() {
  return <div className="content-stretch flex items-center shrink-0" />;
}

function Frame184() {
  return (
    <div className="-translate-y-1/2 absolute h-[32px] left-[-0.42px] top-1/2 w-[65.575px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 65.5752 32">
        <g id="Frame 1618872244">
          <rect fill="var(--fill-0, white)" height="32" rx="16" width="65.5752" />
          <path d={svgPaths.p1a437200} fill="var(--fill-0, #58595B)" id="Union" />
          <path d={svgPaths.p30c40600} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame262() {
  return (
    <div className="h-[24px] relative shrink-0 w-[65.575px]">
      <Frame184 />
    </div>
  );
}

function Frame182() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame183 />
      <Frame262 />
    </div>
  );
}

function Frame29() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots3() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, white)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, white)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, white)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, white)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, white)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame30() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame90() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame29 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots3 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame30 />
        </div>
      </div>
    </div>
  );
}

function Card3() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 4">
      <ImageContainer3 />
      <Frame78 />
      <Frame182 />
      <Frame90 />
    </div>
  );
}

function ImageContainer4() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[161px] left-[calc(50%-2.5px)] top-[calc(50%+6.5px)] w-[331px]" data-name="image 980">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage981} />
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2022 Toyota Yaris Cross</p>
        <p>Hybrid Active</p>
      </div>
    </div>
  );
}

function Frame215() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$30,250</p>
    </div>
  );
}

function Frame93() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame215 />
    </div>
  );
}

function Frame92() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame7 />
      <Frame93 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">18,000mi</p>
    </div>
  );
}

function Frame94() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame13 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame249() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame92 />
        <Frame94 />
      </div>
    </div>
  );
}

function MaskGroup4() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#212e58] from-[33.333%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#70a0d5]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame96() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Blue</p>
      <MaskGroup4 />
    </div>
  );
}

function Frame95() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame96 />
    </div>
  );
}

function Frame98() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame97() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame98 />
    </div>
  );
}

function Cta6() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame250() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta6 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame100() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group4() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group14() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group4 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame99() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame100 />
      <Group14 />
    </div>
  );
}

function Frame251() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame252() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame253() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame101() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame251 />
          <Frame252 />
          <Frame253 />
        </div>
      </div>
    </div>
  );
}

function Frame91() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame249 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame95 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame97 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame250 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame99 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame101 />
    </div>
  );
}

function BestDealBadge1() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame187() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <BestDealBadge1 />
    </div>
  );
}

function Frame186() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <Frame187 />
    </div>
  );
}

function Frame210() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame216() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame188() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame210 />
      <Frame216 />
    </div>
  );
}

function Frame185() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame186 />
      <Frame188 />
    </div>
  );
}

function Frame31() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots4() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame32() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame102() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame31 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots4 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame32 />
        </div>
      </div>
    </div>
  );
}

function Card4() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 5">
      <ImageContainer4 />
      <Frame91 />
      <Frame185 />
      <Frame102 />
    </div>
  );
}

function ImageContainer5() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[160px] left-[calc(50%-1.5px)] top-[calc(50%+10px)] w-[329px]" data-name="image 980">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage982} />
      </div>
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px]">
        {`2023 Toyota Corolla `}
        <br aria-hidden="true" />
        Cross
      </p>
    </div>
  );
}

function Frame217() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$31,250</p>
    </div>
  );
}

function Frame106() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame217 />
    </div>
  );
}

function Frame104() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame8 />
      <Frame106 />
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">24,600mi</p>
    </div>
  );
}

function Frame108() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame14 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame254() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame104 />
        <Frame108 />
      </div>
    </div>
  );
}

function MaskGroup5() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#f1f1f1] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#e9e9e9] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame111() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic White</p>
      <MaskGroup5 />
    </div>
  );
}

function Frame110() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame111 />
    </div>
  );
}

function Frame113() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame112() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame113 />
    </div>
  );
}

function Cta7() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame255() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta7 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame115() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group5() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group15() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group5 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame114() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame115 />
      <Group15 />
    </div>
  );
}

function Frame256() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame257() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame258() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame116() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame256 />
          <Frame257 />
          <Frame258 />
        </div>
      </div>
    </div>
  );
}

function Frame103() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame254 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame110 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame112 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame255 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame114 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame116 />
    </div>
  );
}

function BestDealBadge2() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame191() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <BestDealBadge2 />
    </div>
  );
}

function Frame190() {
  return (
    <div className="content-stretch flex items-center opacity-0 relative shrink-0">
      <Frame191 />
    </div>
  );
}

function Frame218() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame219() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame192() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame218 />
      <Frame219 />
    </div>
  );
}

function Frame189() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame190 />
      <Frame192 />
    </div>
  );
}

function Frame33() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots5() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame34() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame117() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame33 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots5 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame34 />
        </div>
      </div>
    </div>
  );
}

function Card5() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 6">
      <ImageContainer5 />
      <Frame103 />
      <Frame189 />
      <Frame117 />
    </div>
  );
}

function ImageContainer6() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[214px] left-[calc(50%+1.5px)] top-[calc(50%-2px)] w-[381px]" data-name="image 991">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[89.96%] left-[8.55%] max-w-none top-[5.02%] w-[82.9%]" src={imgImage991} />
        </div>
      </div>
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2024 Toyota RAV4</p>
        <p>Hybrid</p>
      </div>
    </div>
  );
}

function Frame220() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$33,500</p>
    </div>
  );
}

function Frame135() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame220 />
    </div>
  );
}

function Frame120() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame15 />
      <Frame135 />
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">6,000mi</p>
    </div>
  );
}

function Frame136() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame16 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame259() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame120 />
        <Frame136 />
      </div>
    </div>
  );
}

function MaskGroup6() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#212e58] from-[33.333%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#70a0d5]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame138() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Ocean Blue</p>
      <MaskGroup6 />
    </div>
  );
}

function Frame137() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame138 />
    </div>
  );
}

function Frame140() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame139() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame140 />
    </div>
  );
}

function Cta8() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame260() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta8 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame142() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group6() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group16() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group6 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame141() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame142 />
      <Group16 />
    </div>
  );
}

function Frame261() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame263() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame264() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame143() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame261 />
          <Frame263 />
          <Frame264 />
        </div>
      </div>
    </div>
  );
}

function Frame118() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame259 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame137 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame139 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame260 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame141 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame143 />
    </div>
  );
}

function PriceDropBadge2() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame194() {
  return (
    <div className="content-stretch flex items-center opacity-0 relative shrink-0">
      <PriceDropBadge2 />
    </div>
  );
}

function Frame221() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame222() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame195() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame221 />
      <Frame222 />
    </div>
  );
}

function Frame193() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame194 />
      <Frame195 />
    </div>
  );
}

function Frame35() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots6() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame36() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame144() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame35 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots6 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame36 />
        </div>
      </div>
    </div>
  );
}

function Card6() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 7">
      <ImageContainer6 />
      <Frame118 />
      <Frame193 />
      <Frame144 />
    </div>
  );
}

function ImageContainer7() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[147px] left-[calc(50%+0.5px)] top-[calc(50%+13.5px)] w-[421.826px]" data-name="image 983">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage983} />
      </div>
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2024 Toyota RAV4</p>
        <p>Hybrid</p>
      </div>
    </div>
  );
}

function Frame223() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$24,250</p>
    </div>
  );
}

function Frame147() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame223 />
    </div>
  );
}

function Frame146() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame17 />
      <Frame147 />
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">6,000mi</p>
    </div>
  );
}

function Frame148() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame18 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame265() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame146 />
        <Frame148 />
      </div>
    </div>
  );
}

function MaskGroup7() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#ffed77] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#dcc200] via-[#caca00] via-[53.247%]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame150() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Sunrise Yellow</p>
      <MaskGroup7 />
    </div>
  );
}

function Frame149() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame150 />
    </div>
  );
}

function Frame152() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame151() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[316px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame152 />
    </div>
  );
}

function Cta9() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame266() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta9 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame154() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group7() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group17() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group7 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame153() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame154 />
      <Group17 />
    </div>
  );
}

function Frame267() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame268() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame269() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame155() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame267 />
          <Frame268 />
          <Frame269 />
        </div>
      </div>
    </div>
  );
}

function Frame145() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame265 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame149 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame151 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame266 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame153 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame155 />
    </div>
  );
}

function BestDealBadge3() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame198() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <BestDealBadge3 />
    </div>
  );
}

function Frame197() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <Frame198 />
    </div>
  );
}

function Frame224() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame225() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame199() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame224 />
      <Frame225 />
    </div>
  );
}

function Frame196() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame197 />
      <Frame199 />
    </div>
  );
}

function Frame37() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots7() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame38() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame156() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame37 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots7 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame38 />
        </div>
      </div>
    </div>
  );
}

function Card7() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 8">
      <ImageContainer7 />
      <Frame145 />
      <Frame196 />
      <Frame156 />
    </div>
  );
}

function ImageContainer8() {
  return (
    <div className="h-[256px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[160px] left-[calc(50%+1.5px)] top-[calc(50%+9px)] w-[284.444px]" data-name="image 979">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage979} />
      </div>
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2025 Toyota RAV4</p>
        <p>Limited Edition</p>
      </div>
    </div>
  );
}

function Frame226() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$30,900</p>
    </div>
  );
}

function Frame159() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame226 />
    </div>
  );
}

function Frame158() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-full">
      <Frame19 />
      <Frame159 />
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">6,000mi</p>
    </div>
  );
}

function Frame160() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-full">
      <Frame20 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame270() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="content-stretch flex flex-col gap-[4px] items-start px-[16px] relative w-full">
        <Frame158 />
        <Frame160 />
      </div>
    </div>
  );
}

function MaskGroup8() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#c4c2c2] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#817d7d] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame162() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Gray</p>
      <MaskGroup8 />
    </div>
  );
}

function Frame161() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[314px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame162 />
    </div>
  );
}

function Frame164() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame163() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[314px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame164 />
    </div>
  );
}

function Cta10() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame271() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta10 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame166() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group8() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group18() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group8 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame165() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[310px]">
      <Frame166 />
      <Group18 />
    </div>
  );
}

function Frame272() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame273() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame274() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame167() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame272 />
          <Frame273 />
          <Frame274 />
        </div>
      </div>
    </div>
  );
}

function Frame157() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame270 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame161 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame163 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[342px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[342px] opacity-10 w-px" />
        </div>
      </div>
      <Frame271 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame165 />
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame167 />
    </div>
  );
}

function BestDealBadge4() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame202() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <BestDealBadge4 />
    </div>
  );
}

function Frame201() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <Frame202 />
    </div>
  );
}

function Frame227() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame228() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame203() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame227 />
      <Frame228 />
    </div>
  );
}

function Frame200() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[342px]">
      <Frame201 />
      <Frame203 />
    </div>
  );
}

function Frame39() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots8() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_-8.33%_-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 52 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" opacity="0.3" rx="3" ry="3" />
              <path d={svgPaths.p1e20f300} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame40() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame168() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex h-[38px] items-center justify-between left-1/2 top-[218px] w-[342px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame39 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots8 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame40 />
        </div>
      </div>
    </div>
  );
}

function Card8() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-full" data-name="CARD 9">
      <ImageContainer8 />
      <Frame157 />
      <Frame200 />
      <Frame168 />
    </div>
  );
}

function Cards() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[16px] items-start left-[24px] top-[556px] w-[342px]" data-name="CARDS">
      <Card />
      <Card1 />
      <Card2 />
      <Card3 />
      <Card4 />
      <Card5 />
      <Card6 />
      <Card7 />
      <Card8 />
    </div>
  );
}

export default function MobileSearch() {
  return (
    <div className="bg-[#f4f4f4] relative size-full" data-name="Mobile Search">
      <FooterM />
      <div className="absolute bg-white content-stretch flex h-[64px] items-center justify-between left-0 p-[15px] top-0 w-[390px]" data-name="Navigation_M">
        <div aria-hidden="true" className="absolute border-[rgba(88,89,91,0.1)] border-b border-solid inset-0 pointer-events-none" />
        <Logo />
        <CtAs />
      </div>
      <Frame175 />
      <Cards />
    </div>
  );
}