import svgPaths from "./svg-c5ttzs3ltt";
import imgImage979 from "figma:asset/3579f5a46306271a52ef6df1c27c5c9275845372.png";
import imgImage990 from "figma:asset/fe6be21663a63f10771602fdece38074f80f8573.png";
import imgImage980 from "figma:asset/b6698f7145da88172272ca97c2cb2bf7bba3d1af.png";
import imgImage981 from "figma:asset/2a7c58bfbb1822785643b5307123a107bf86c9e9.png";
import imgImage982 from "figma:asset/f0956ff12948219a4c59e52d07d0cc9e57755bf3.png";
import imgImage991 from "figma:asset/f084c73296c7d07a55e5634fba59677b6bc1576a.png";
import imgImage983 from "figma:asset/2076f6883092c32026cb3bc418a6ade99b2caaf8.png";
import imgImage984 from "figma:asset/d6835baa66fd349c7f94b548b0c9d1c3742001ff.png";
import imgImage985 from "figma:asset/a1f217c3c2fe117071c541686d84a93826c515d7.png";
import imgImage986 from "figma:asset/0753e9fe23c6e16a8d5aaf51b10a32db86f46a7c.png";
import { imgRectangle14593 } from "./svg-732sy";

function Frame130() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">{`SUV  `}</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame119() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">$30k-40k</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame121() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Heated Seats</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame123() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Under 50k mi</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame125() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Leather Seats</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame127() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">4 Doors</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame129() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[4px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">2023 or newer</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame117() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <Frame130 />
      <Frame119 />
      <Frame121 />
      <Frame123 />
      <Frame125 />
      <Frame127 />
      <Frame129 />
    </div>
  );
}

function Frame131() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Sunroof</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame133() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">4WD</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame135() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Leather Seats</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame137() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Hybrid</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame140() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Apple Carplay</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame141() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Hands-Free</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame142() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">LED Highlights</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame143() {
  return (
    <div className="bg-[rgba(0,0,0,0)] content-stretch flex gap-[8px] items-center px-[8px] py-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">LED Taillights</p>
      <div className="relative shrink-0 size-[8px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 8 8">
          <path d={svgPaths.p1e4ea000} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Frame1() {
  return (
    <div className="bg-black content-stretch flex items-center justify-center px-[8px] py-[10px] relative rounded-[100px] shrink-0 w-[64px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-center text-white">Reset</p>
    </div>
  );
}

function Frame139() {
  return (
    <div className="content-stretch flex gap-[4px] items-center relative shrink-0">
      <Frame131 />
      <Frame133 />
      <Frame135 />
      <Frame137 />
      <Frame140 />
      <Frame141 />
      <Frame142 />
      <Frame143 />
      <Frame1 />
    </div>
  );
}

function Frame183() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[8px] items-end right-[80px] top-[282px]">
      <Frame117 />
      <Frame139 />
    </div>
  );
}

function Frame() {
  return (
    <div className="content-stretch flex flex-col items-start justify-center relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[18px] text-black uppercase">ARROW</p>
    </div>
  );
}

function Logo() {
  return (
    <div className="absolute content-stretch flex gap-[16px] items-center left-[80px] top-[20px] w-[321.67px]" data-name="Logo">
      <div className="bg-[#eb0a1e] shrink-0 size-[40px]" data-name="Logo" />
      <Frame />
    </div>
  );
}

function Wishlist() {
  return (
    <div className="absolute left-[164px] size-[40px] top-[2px]" data-name="wishlist">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 40 40">
        <g id="wishlist">
          <circle cx="20" cy="20" id="Ellipse 1" r="19.5" stroke="var(--stroke-0, black)" strokeOpacity="0.3" />
          <path d={svgPaths.p23ab3a00} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame52() {
  return (
    <div className="absolute bg-[#eb0a1e] left-[11.66px] rounded-[40px] size-[18px] top-[11px]">
      <div className="flex flex-col items-center justify-center size-full">
        <div className="content-stretch flex flex-col items-center justify-center p-[10px] relative size-full">
          <div className="-translate-x-1/2 -translate-y-full absolute flex flex-col font-['Toyota_Type:Semibold',sans-serif] h-[14px] justify-end leading-[0] left-[calc(50%+0.2px)] not-italic overflow-hidden text-[14px] text-center text-ellipsis text-white top-[calc(50%+6px)] w-[4px] whitespace-nowrap">
            <p className="leading-[15px] overflow-hidden">S</p>
          </div>
        </div>
      </div>
    </div>
  );
}

function Frame79() {
  return (
    <div className="absolute h-[40px] left-[220px] top-[2px] w-[110px]">
      <div className="absolute border border-black border-solid h-[40px] left-0 opacity-30 rounded-[100px] top-0 w-[110px]" />
      <p className="-translate-x-1/2 absolute font-['Toyota_Type:Semibold',sans-serif] leading-[normal] left-[calc(50%+11.1px)] not-italic text-[#111] text-[14px] text-center top-[9px] w-[52.199px] whitespace-pre-wrap">Sarah...</p>
      <Frame52 />
    </div>
  );
}

function Cta() {
  return (
    <div className="absolute contents left-[164px] top-[2px]" data-name="CTA">
      <Wishlist />
      <Frame79 />
    </div>
  );
}

function Group() {
  return (
    <div className="h-[13.333px] relative shrink-0 w-[10.667px]">
      <div className="absolute inset-[-5%_-6.25%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 12 14.6665">
          <g id="Group 2">
            <path d={svgPaths.pdde7000} id="Vector" stroke="var(--stroke-0, #EB0D1C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p2078cbb0} id="Vector_2" stroke="var(--stroke-0, #EB0D1C)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame187() {
  return (
    <div className="absolute content-stretch flex gap-[6px] items-center left-0 top-[11px]">
      <Group />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#111] text-[14px] text-right">Buffalo, WV 25033</p>
    </div>
  );
}

function Frame188() {
  return (
    <div className="absolute h-[42px] left-[1027px] top-[18px] w-[330px]">
      <Cta />
      <Frame187 />
    </div>
  );
}

function NavigationD() {
  return (
    <div className="absolute bg-white h-[80px] left-0 top-0 w-[1440px]" data-name="Navigation_D">
      <div aria-hidden="true" className="absolute border-[rgba(88,89,91,0.1)] border-b border-solid inset-[0_0_-1px_0] pointer-events-none" />
      <Logo />
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[normal] left-[calc(50%-169px)] not-italic text-[#111] text-[14px] top-[30px]">{`Buy                Sell                Finance                Why Arrow`}</p>
      <Frame188 />
    </div>
  );
}

function Frame145() {
  return (
    <div className="bg-white content-stretch flex items-center p-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Off-road</p>
    </div>
  );
}

function Frame146() {
  return (
    <div className="bg-white content-stretch flex items-center p-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Eco-friendly</p>
    </div>
  );
}

function Frame138() {
  return (
    <div className="bg-white content-stretch flex items-center p-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">High safety rating</p>
    </div>
  );
}

function Frame134() {
  return (
    <div className="bg-white content-stretch flex items-center p-[10px] relative rounded-[100px] shrink-0">
      <div aria-hidden="true" className="absolute border border-[rgba(0,0,0,0.1)] border-solid inset-0 pointer-events-none rounded-[100px]" />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[12px] text-black text-center">Near me</p>
    </div>
  );
}

function Frame144() {
  return (
    <div className="content-stretch flex gap-[8px] items-center relative shrink-0">
      <Frame145 />
      <Frame146 />
      <Frame138 />
      <Frame134 />
    </div>
  );
}

function Frame184() {
  return (
    <div className="absolute content-stretch flex items-start justify-end left-[calc(41.67%+81px)] top-[196px] w-[679px]">
      <Frame144 />
    </div>
  );
}

function Group15() {
  return (
    <div className="h-[19.127px] relative shrink-0 w-[19.5px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 19.5 19.127">
        <g id="Group 1000004550">
          <path d={svgPaths.p2a089500} fill="var(--fill-0, #EB0D1C)" id="Vector" />
          <path d={svgPaths.p131f5fc0} fill="var(--fill-0, #EB0D1C)" id="Vector_2" />
          <path d={svgPaths.p5f37c00} fill="var(--fill-0, #EB0D1C)" id="Vector_3" />
        </g>
      </svg>
    </div>
  );
}

function Frame26() {
  return (
    <div className="-translate-y-1/2 absolute content-stretch flex gap-[8px] items-center left-[20.5px] top-[calc(50%-0.42px)]">
      <Group15 />
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[15px] text-black">
        <span className="leading-[normal]">{`SUV under 35k with `}</span>
        <span className="font-['Toyota_Type:Bold',sans-serif] leading-[normal]">low miles</span>
      </p>
    </div>
  );
}

function Mic() {
  return (
    <div className="h-[16px] relative shrink-0 w-[10.182px]" data-name="mic">
      <div className="absolute inset-[-3.75%_-5.89%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 11.3818 17.2">
          <g id="mic">
            <path d={svgPaths.p1733b100} id="Vector" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d={svgPaths.p3b194780} id="Vector_2" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d="M5.6918 13.6898V16.5989" id="Vector_3" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
            <path d="M2.78164 16.6H8.59979" id="Vector_4" stroke="var(--stroke-0, #111111)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Cta1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="CTA">
      <div className="bg-[#ff0202] col-1 h-[40px] ml-0 mt-0 rounded-[100px] row-1 w-[90px]" />
      <p className="col-1 font-['Toyota_Type:Semibold',sans-serif] leading-[normal] ml-[13.5px] mt-[9px] not-italic relative row-1 text-[14px] text-center text-white w-[63px] whitespace-pre-wrap">Search</p>
    </div>
  );
}

function Frame27() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <Cta1 />
    </div>
  );
}

function Frame98() {
  return (
    <div className="absolute content-stretch flex gap-[16px] items-center right-[7.32px] top-[8px]">
      <Mic />
      <Frame27 />
    </div>
  );
}

function SearchInput() {
  return (
    <div className="absolute contents left-0 top-0" data-name="search input">
      <div className="absolute bg-white h-[56px] left-0 rounded-[100px] top-0 w-[848px]" />
      <Frame26 />
      <Frame98 />
    </div>
  );
}

function Frame180() {
  return (
    <div className="absolute h-[56px] left-[calc(33.33%+32px)] top-[116px] w-[848px]">
      <SearchInput />
    </div>
  );
}

function Filters() {
  return (
    <div className="absolute contents left-0 top-0" data-name="Filters">
      <div className="absolute bg-[#ff0202] left-0 rounded-[100px] size-[40px] top-0" />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute left-[calc(50%-84px)] overflow-clip size-[16px] top-1/2" data-name="filter-lines">
        <div className="absolute bottom-1/4 left-[12.5%] right-[12.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-12.5%_-8.33%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 10">
              <path d="M3 5H11M1 1H13M5 9H9" id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" />
            </svg>
          </div>
        </div>
        <div className="absolute bottom-1/4 left-[12.5%] right-[12.5%] top-1/4" data-name="Icon">
          <div className="absolute inset-[-6.25%_-4.17%]">
            <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 13 9">
              <path d={svgPaths.pf480500} id="Icon" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
}

function Cta2() {
  return (
    <div className="absolute contents left-[53px] top-[23px]" data-name="CTA">
      <p className="absolute font-['Toyota_Type:Semibold',sans-serif] leading-[normal] left-[calc(50%-51px)] not-italic text-[#121212] text-[12px] top-[23px]">Sort by: Recommended</p>
      <div className="absolute h-[6.504px] left-[196.09px] top-[29.75px] w-[11.504px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 11.5039 6.50377">
          <path d={svgPaths.p12bd8c80} fill="var(--fill-0, black)" id="Vector" />
        </svg>
      </div>
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute contents left-[53px] top-[23px]">
      <Cta2 />
    </div>
  );
}

function Frame179() {
  return (
    <div className="absolute h-[40px] left-[80px] top-[295px] w-[208px]">
      <Filters />
      <p className="absolute font-['Toyota_Type:Semibold',sans-serif] leading-[normal] left-[52px] not-italic text-[#111] text-[16px] top-[-2.5px] w-[145px] whitespace-pre-wrap">247 vehicles found</p>
      <Group13 />
    </div>
  );
}

function Container2() {
  return (
    <div className="h-[31.997px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Bold',sans-serif] leading-[32px] left-0 not-italic text-[#eb0a1e] text-[24px] top-[-0.33px] tracking-[0.0703px]">Arrow</p>
    </div>
  );
}

function Paragraph() {
  return (
    <div className="h-[40px] relative shrink-0 w-full" data-name="Paragraph">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px] w-[199px] whitespace-pre-wrap">Your trusted partner for quality pre-owned vehicles.</p>
    </div>
  );
}

function Icon() {
  return (
    <div className="relative shrink-0 size-[15.998px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9983 15.9983">
        <g clipPath="url(#clip0_1_1767)" id="Icon">
          <path d={svgPaths.p17489b80} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33319" />
        </g>
        <defs>
          <clipPath id="clip0_1_1767">
            <rect fill="white" height="15.9983" width="15.9983" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[35.998px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon />
      </div>
    </div>
  );
}

function Icon1() {
  return (
    <div className="relative shrink-0 size-[15.998px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9983 15.9983">
        <g clipPath="url(#clip0_1_1655)" id="Icon">
          <path d={svgPaths.p232e2500} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33319" />
        </g>
        <defs>
          <clipPath id="clip0_1_1655">
            <rect fill="white" height="15.9983" width="15.9983" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button1() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[35.998px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon1 />
      </div>
    </div>
  );
}

function Icon2() {
  return (
    <div className="relative shrink-0 size-[15.998px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9983 15.9983">
        <g clipPath="url(#clip0_1_1732)" id="Icon">
          <path d={svgPaths.p8aa3600} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33319" />
          <path d={svgPaths.p1c7e3980} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33319" />
          <path d="M11.668 4.33203H11.6746" id="Vector_3" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33319" />
        </g>
        <defs>
          <clipPath id="clip0_1_1732">
            <rect fill="white" height="15.9983" width="15.9983" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button2() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[35.998px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon2 />
      </div>
    </div>
  );
}

function Icon3() {
  return (
    <div className="relative shrink-0 size-[15.998px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15.9983 15.9983">
        <g clipPath="url(#clip0_1_1757)" id="Icon">
          <path d={svgPaths.pb5a0100} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33319" />
          <path d={svgPaths.p454480} id="Vector_2" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33319" />
        </g>
        <defs>
          <clipPath id="clip0_1_1757">
            <rect fill="white" height="15.9983" width="15.9983" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Button3() {
  return (
    <div className="relative rounded-[8px] shrink-0 size-[35.998px]" data-name="Button">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex items-center justify-center relative size-full">
        <Icon3 />
      </div>
    </div>
  );
}

function Container3() {
  return (
    <div className="content-stretch flex gap-[11.997px] h-[35.998px] items-start relative shrink-0 w-full" data-name="Container">
      <Button />
      <Button1 />
      <Button2 />
      <Button3 />
    </div>
  );
}

function Container1() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.998px] h-[194.948px] items-start left-0 top-0 w-[217.604px]" data-name="Container">
      <Container2 />
      <Paragraph />
      <Container3 />
    </div>
  );
}

function Heading() {
  return (
    <div className="h-[27.005px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Toyota_Type:Bold',sans-serif] leading-[27px] left-0 not-italic text-[18px] text-white top-[0.78px] tracking-[-0.4395px]">Shop</p>
    </div>
  );
}

function Link() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.44px] w-[62.3px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Buy a Car</p>
    </div>
  );
}

function ListItem() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link />
    </div>
  );
}

function Link1() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.44px] w-[82.786px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Sell Your Car</p>
    </div>
  );
}

function ListItem1() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link1 />
    </div>
  );
}

function Link2() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[104.714px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Finance Options</p>
    </div>
  );
}

function ListItem2() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link2 />
    </div>
  );
}

function Link3() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[94.036px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Trade-In Value</p>
    </div>
  );
}

function ListItem3() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link3 />
    </div>
  );
}

function List() {
  return (
    <div className="content-stretch flex flex-col gap-[7.995px] h-[151.944px] items-start relative shrink-0 w-full" data-name="List">
      <ListItem />
      <ListItem1 />
      <ListItem2 />
      <ListItem3 />
    </div>
  );
}

function Container4() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.998px] h-[194.948px] items-start left-[271.61px] top-0 w-[217.604px]" data-name="Container">
      <Heading />
      <List />
    </div>
  );
}

function Heading1() {
  return (
    <div className="h-[27.005px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Toyota_Type:Bold',sans-serif] leading-[27px] left-0 not-italic text-[18px] text-white top-[0.78px] tracking-[-0.4395px]">Support</p>
    </div>
  );
}

function Link4() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.44px] w-[72.413px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Contact Us</p>
    </div>
  );
}

function ListItem4() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link4 />
    </div>
  );
}

function Link5() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.44px] w-[34.019px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">FAQs</p>
    </div>
  );
}

function ListItem5() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link5 />
    </div>
  );
}

function Link6() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[95.833px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Financing Help</p>
    </div>
  );
}

function ListItem6() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link6 />
    </div>
  );
}

function Link7() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[137.3px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">{`Returns & Exchanges`}</p>
    </div>
  );
}

function ListItem7() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link7 />
    </div>
  );
}

function ListItem8() {
  return <div className="h-[23.993px] shrink-0 w-full" data-name="List Item" />;
}

function List1() {
  return (
    <div className="content-stretch flex flex-col gap-[7.995px] h-[151.944px] items-start relative shrink-0 w-full" data-name="List">
      <ListItem4 />
      <ListItem5 />
      <ListItem6 />
      <ListItem7 />
      <ListItem8 />
    </div>
  );
}

function Container5() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.998px] h-[194.948px] items-start left-[543.21px] top-0 w-[217.604px]" data-name="Container">
      <Heading1 />
      <List1 />
    </div>
  );
}

function Heading2() {
  return (
    <div className="h-[27.005px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Toyota_Type:Bold',sans-serif] leading-[27px] left-0 not-italic text-[18px] text-white top-[0.78px] tracking-[-0.4395px]">Company</p>
    </div>
  );
}

function Link8() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.44px] w-[85.608px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">About Arrow</p>
    </div>
  );
}

function ListItem9() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link8 />
    </div>
  );
}

function Link9() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[35.79px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Press</p>
    </div>
  );
}

function ListItem10() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link9 />
    </div>
  );
}

function Link10() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[81.363px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Partnerships</p>
    </div>
  );
}

function ListItem11() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link10 />
    </div>
  );
}

function Link11() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[62.405px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Locations</p>
    </div>
  );
}

function ListItem12() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link11 />
    </div>
  );
}

function Link12() {
  return <div className="absolute h-[16.111px] left-0 top-[4.45px] w-[50.347px]" data-name="Link" />;
}

function ListItem13() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link12 />
    </div>
  );
}

function List2() {
  return (
    <div className="content-stretch flex flex-col gap-[7.995px] h-[151.944px] items-start relative shrink-0 w-full" data-name="List">
      <ListItem9 />
      <ListItem10 />
      <ListItem11 />
      <ListItem12 />
      <ListItem13 />
    </div>
  );
}

function Container6() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.998px] h-[194.948px] items-start left-[814.81px] top-0 w-[217.604px]" data-name="Container">
      <Heading2 />
      <List2 />
    </div>
  );
}

function Heading3() {
  return (
    <div className="h-[27.005px] relative shrink-0 w-full" data-name="Heading 3">
      <p className="absolute font-['Toyota_Type:Bold',sans-serif] leading-[27px] left-0 not-italic text-[18px] text-white top-[0.78px] tracking-[-0.4395px]">Legal</p>
    </div>
  );
}

function Link13() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.44px] w-[89.392px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Privacy Policy</p>
    </div>
  );
}

function ListItem14() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link13 />
    </div>
  );
}

function Link14() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.44px] w-[108.49px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Terms of Service</p>
    </div>
  );
}

function ListItem15() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link14 />
    </div>
  );
}

function Link15() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[87.005px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Cookie Policy</p>
    </div>
  );
}

function ListItem16() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link15 />
    </div>
  );
}

function Link16() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[80.46px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Accessibility</p>
    </div>
  );
}

function ListItem17() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link16 />
    </div>
  );
}

function Link17() {
  return (
    <div className="absolute content-stretch flex h-[16.111px] items-start left-0 top-[4.45px] w-[52.76px]" data-name="Link">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[20px] not-italic relative shrink-0 text-[#99a1af] text-[14px] tracking-[-0.1504px]">Sitemap</p>
    </div>
  );
}

function ListItem18() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="List Item">
      <Link17 />
    </div>
  );
}

function List3() {
  return (
    <div className="content-stretch flex flex-col gap-[7.995px] h-[151.944px] items-start relative shrink-0 w-full" data-name="List">
      <ListItem14 />
      <ListItem15 />
      <ListItem16 />
      <ListItem17 />
      <ListItem18 />
    </div>
  );
}

function Container7() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[15.998px] h-[194.948px] items-start left-[1086.42px] top-0 w-[217.604px]" data-name="Container">
      <Heading3 />
      <List3 />
    </div>
  );
}

function Container() {
  return (
    <div className="absolute h-[195px] left-[80px] top-[48px] w-[1280px]" data-name="Container">
      <Container1 />
      <Container4 />
      <Container5 />
      <Container6 />
      <Container7 />
    </div>
  );
}

function Icon4() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g clipPath="url(#clip0_1_1642)" id="Icon">
          <path d={svgPaths.p2e7ef300} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
        <defs>
          <clipPath id="clip0_1_1642">
            <rect fill="white" height="20" width="20" />
          </clipPath>
        </defs>
      </svg>
    </div>
  );
}

function Container12() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">Call Us</p>
    </div>
  );
}

function Container13() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Semibold',sans-serif] leading-[24px] left-0 not-italic text-[16px] text-white top-[-0.78px] tracking-[-0.3125px]">1-800-GO-Arrow</p>
    </div>
  );
}

function Container11() {
  return (
    <div className="h-[43.993px] relative shrink-0 w-[146.962px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container12 />
        <Container13 />
      </div>
    </div>
  );
}

function Container10() {
  return (
    <div className="absolute content-stretch flex gap-[11.997px] h-[44px] items-center left-0 top-[-0.55px] w-[209px]" data-name="Container">
      <Icon4 />
      <Container11 />
    </div>
  );
}

function Icon5() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p1b42e780} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.pbc79760} id="Vector_2" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container16() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">Email Us</p>
    </div>
  );
}

function Container17() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Semibold',sans-serif] leading-[24px] left-0 not-italic text-[16px] text-white top-[-0.78px] tracking-[-0.3125px]">support@arrow.com</p>
    </div>
  );
}

function Container15() {
  return (
    <div className="h-[43.993px] relative shrink-0 w-[159.566px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container16 />
        <Container17 />
      </div>
    </div>
  );
}

function Container14() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex gap-[11.997px] h-[44px] items-center left-[calc(50%+95.5px)] top-[-0.55px] w-[389px]" data-name="Container">
      <Icon5 />
      <Container15 />
    </div>
  );
}

function Icon6() {
  return (
    <div className="relative shrink-0 size-[20px]" data-name="Icon">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 20 20">
        <g id="Icon">
          <path d={svgPaths.p370f1780} id="Vector" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
          <path d={svgPaths.p28175700} id="Vector_2" stroke="var(--stroke-0, #EB0A1E)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.66667" />
        </g>
      </svg>
    </div>
  );
}

function Container20() {
  return (
    <div className="h-[20px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">Find a Location</p>
    </div>
  );
}

function Container21() {
  return (
    <div className="h-[23.993px] relative shrink-0 w-full" data-name="Container">
      <p className="absolute font-['Toyota_Type:Semibold',sans-serif] leading-[24px] left-0 not-italic text-[16px] text-white top-[-0.78px] tracking-[-0.3125px]">Dealership Locator</p>
    </div>
  );
}

function Container19() {
  return (
    <div className="h-[43.993px] relative shrink-0 w-[142.769px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid content-stretch flex flex-col items-start relative size-full">
        <Container20 />
        <Container21 />
      </div>
    </div>
  );
}

function Container18() {
  return (
    <div className="absolute content-stretch flex gap-[11.997px] h-[44px] items-center left-[1078px] top-[-0.49px] w-[389px]" data-name="Container">
      <Icon6 />
      <Container19 />
    </div>
  );
}

function Container9() {
  return (
    <div className="h-[43.993px] relative shrink-0 w-full" data-name="Container">
      <Container10 />
      <Container14 />
      <Container18 />
    </div>
  );
}

function Container8() {
  return (
    <div className="absolute content-stretch flex flex-col h-[77px] items-start left-[80px] pt-[32.552px] top-[275px] w-[1280px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#1e2939] border-solid border-t-[0.556px] inset-0 pointer-events-none" />
      <Container9 />
    </div>
  );
}

function Container23() {
  return (
    <div className="h-[20px] relative shrink-0 w-[345.556px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">© 2026 Toyota Financial Services. All rights reserved.</p>
      </div>
    </div>
  );
}

function Container24() {
  return (
    <div className="h-[20px] relative shrink-0 w-[327.005px]" data-name="Container">
      <div className="bg-clip-padding border-0 border-[transparent] border-solid relative size-full">
        <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[20px] left-0 not-italic text-[#99a1af] text-[14px] top-[0.67px] tracking-[-0.1504px]">Project ARROW (331) • R1 Launch: March 31, 2026</p>
      </div>
    </div>
  );
}

function Container22() {
  return (
    <div className="absolute content-stretch flex h-[45px] items-center justify-between left-[80px] pt-[0.556px] top-[383px] w-[1280px]" data-name="Container">
      <div aria-hidden="true" className="absolute border-[#1e2939] border-solid border-t-[0.556px] inset-0 pointer-events-none" />
      <Container23 />
      <Container24 />
    </div>
  );
}

function Footer() {
  return (
    <div className="absolute bg-[#1a1a1a] h-[476px] left-0 top-[3116px] w-[1440px]" data-name="Footer">
      <Container />
      <Container8 />
      <Container22 />
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute contents left-0 top-[3116px]">
      <Footer />
    </div>
  );
}

function ImageContainer() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[190px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[339px]" data-name="image 979">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage979} />
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px]">
        {`2023 Toyota Corolla `}
        <br aria-hidden="true" />
        Cross
      </p>
    </div>
  );
}

function Frame275() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$31,250</p>
    </div>
  );
}

function Frame54() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#06c] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame275 />
    </div>
  );
}

function Frame63() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame2 />
      <Frame54 />
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">18,000mi</p>
    </div>
  );
}

function Frame56() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame64() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame8 />
      <Frame56 />
    </div>
  );
}

function Frame320() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame63 />
      <Frame64 />
    </div>
  );
}

function MaskGroup() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#2e0507] from-[33.333%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#ff3b42]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame57() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Red</p>
      <MaskGroup />
    </div>
  );
}

function Frame58() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame57 />
    </div>
  );
}

function Frame60() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame59() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame60 />
    </div>
  );
}

function Cta3() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">99% Match</p>
    </div>
  );
}

function Frame321() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta3 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame61() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group1() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group16() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group1 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame65() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame61 />
      <Group16 />
    </div>
  );
}

function Frame312() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame313() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame311() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame66() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame312 />
          <Frame313 />
          <Frame311 />
        </div>
      </div>
    </div>
  );
}

function Frame62() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame320 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame58 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame59 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame321 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame65 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame66 />
    </div>
  );
}

function PriceDropBadge() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame233() {
  return (
    <div className="content-stretch flex items-center opacity-0 relative shrink-0">
      <PriceDropBadge />
    </div>
  );
}

function Frame268() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame269() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame230() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame268 />
      <Frame269 />
    </div>
  );
}

function Frame229() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame233 />
      <Frame230 />
    </div>
  );
}

function Frame28() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame29() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame67() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame28 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame29 />
        </div>
      </div>
    </div>
  );
}

function Card() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer />
      <Frame62 />
      <Frame229 />
      <Frame67 />
    </div>
  );
}

function ImageContainer1() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[271px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[481px]" data-name="image 990">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage990} />
      </div>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px]">
        2022 Toyota RAV4
        <br aria-hidden="true" />
        Hybrid
      </p>
    </div>
  );
}

function Frame276() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$31,250</p>
    </div>
  );
}

function Frame55() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="[text-decoration-skip-ink:none] decoration-solid leading-[normal] line-through">4,250</span>
      </p>
      <Frame276 />
    </div>
  );
}

function Frame69() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame3 />
      <Frame55 />
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">24,600mi</p>
    </div>
  );
}

function Frame71() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame70() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame9 />
      <Frame71 />
    </div>
  );
}

function Frame323() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame69 />
      <Frame70 />
    </div>
  );
}

function MaskGroup1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#f1f1f1] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#e9e9e9] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame73() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic White</p>
      <MaskGroup1 />
    </div>
  );
}

function Frame72() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame73 />
    </div>
  );
}

function Frame75() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame74() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame75 />
    </div>
  );
}

function Cta4() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0 w-[86.667px]" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">98% Match</p>
    </div>
  );
}

function Frame324() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta4 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame77() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group2() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group17() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group2 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame76() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame77 />
      <Group17 />
    </div>
  );
}

function Frame314() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame315() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame316() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame78() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame314 />
          <Frame315 />
          <Frame316 />
        </div>
      </div>
    </div>
  );
}

function Frame68() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame323 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame72 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame74 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame324 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame76 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame78 />
    </div>
  );
}

function BestDealBadge() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame234() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <BestDealBadge />
    </div>
  );
}

function Frame270() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame271() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame232() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame270 />
      <Frame271 />
    </div>
  );
}

function Frame231() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame234 />
      <Frame232 />
    </div>
  );
}

function Frame30() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots1() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame31() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame80() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame30 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots1 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame31 />
        </div>
      </div>
    </div>
  );
}

function Card1() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer1 />
      <Frame68 />
      <Frame231 />
      <Frame80 />
    </div>
  );
}

function ImageContainer2() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[181px] left-1/2 top-[calc(50%+30.5px)] w-[352px]" data-name="image 980">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-[-26.48%] max-w-none top-0 w-[147.55%]" src={imgImage980} />
        </div>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2023 Toyota RAV4</p>
        <p>Hybrid</p>
      </div>
    </div>
  );
}

function Frame277() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$33,250</p>
    </div>
  );
}

function Frame83() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$3</span>
        <span className="leading-[normal]">4</span>
        <span className="leading-[normal]">,900</span>
      </p>
      <Frame277 />
    </div>
  );
}

function Frame82() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame4 />
      <Frame83 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">21,000mi</p>
    </div>
  );
}

function Frame85() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame84() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame10 />
      <Frame85 />
    </div>
  );
}

function Frame325() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame82 />
      <Frame84 />
    </div>
  );
}

function MaskGroup2() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#155681] from-[39.583%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#5ab2ff]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame87() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Blue</p>
      <MaskGroup2 />
    </div>
  );
}

function Frame86() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame87 />
    </div>
  );
}

function Frame89() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame88() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame89 />
    </div>
  );
}

function Cta5() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">78% Match</p>
    </div>
  );
}

function Frame326() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta5 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame91() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group3() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group18() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group3 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame90() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame91 />
      <Group18 />
    </div>
  );
}

function Frame317() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame318() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame319() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame92() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame317 />
          <Frame318 />
          <Frame319 />
        </div>
      </div>
    </div>
  );
}

function Frame81() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame325 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame86 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame88 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame326 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame90 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame92 />
    </div>
  );
}

function PriceDropBadge1() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame236() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <PriceDropBadge1 />
    </div>
  );
}

function Frame272() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame273() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame237() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame272 />
      <Frame273 />
    </div>
  );
}

function Frame235() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame236 />
      <Frame237 />
    </div>
  );
}

function Frame32() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots2() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame33() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame93() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame32 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots2 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame33 />
        </div>
      </div>
    </div>
  );
}

function Card2() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer2 />
      <Frame81 />
      <Frame235 />
      <Frame93 />
    </div>
  );
}

function Frame53() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0 w-full">
      <Card />
      <Card1 />
      <Card2 />
    </div>
  );
}

function ImageContainer3() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[271px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[481px]" data-name="image 990">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage990} />
      </div>
    </div>
  );
}

function Frame5() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px]">
        2024 Toyota RAV4
        <br aria-hidden="true" />
        Hybrid
      </p>
    </div>
  );
}

function Frame278() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$29,990</p>
    </div>
  );
}

function Frame97() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame278 />
    </div>
  );
}

function Frame96() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame5 />
      <Frame97 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">24,500mi</p>
    </div>
  );
}

function Frame100() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame99() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame11 />
      <Frame100 />
    </div>
  );
}

function Frame327() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame96 />
      <Frame99 />
    </div>
  );
}

function MaskGroup3() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#f1f1f1] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#e9e9e9] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame102() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic White</p>
      <MaskGroup3 />
    </div>
  );
}

function Frame101() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame102 />
    </div>
  );
}

function Frame104() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame103() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame104 />
    </div>
  );
}

function Cta6() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0 w-[86.667px]" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">85% Match</p>
    </div>
  );
}

function Frame328() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta6 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame106() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group4() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group19() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group4 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame105() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame106 />
      <Group19 />
    </div>
  );
}

function Frame329() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame330() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame331() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame107() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame329 />
          <Frame330 />
          <Frame331 />
        </div>
      </div>
    </div>
  );
}

function Frame95() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame327 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame101 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame103 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame328 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame105 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame107 />
    </div>
  );
}

function BestDealBadge1() {
  return (
    <div className="bg-[#0e5b32] content-stretch flex gap-[7px] h-[24px] items-center justify-center opacity-0 px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p2e095690} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Good Price</p>
    </div>
  );
}

function Frame274() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame279() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame239() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame274 />
      <Frame279 />
    </div>
  );
}

function Frame238() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <BestDealBadge1 />
      <Frame239 />
    </div>
  );
}

function Frame34() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots3() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame35() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame108() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame34 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots3 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame35 />
        </div>
      </div>
    </div>
  );
}

function Card3() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer3 />
      <Frame95 />
      <Frame238 />
      <Frame108 />
    </div>
  );
}

function ImageContainer4() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[186px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[382px]" data-name="image 980">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage981} />
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2022 Toyota Yaris Cross</p>
        <p>Hybrid Active</p>
      </div>
    </div>
  );
}

function Frame280() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$30,250</p>
    </div>
  );
}

function Frame111() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame280 />
    </div>
  );
}

function Frame110() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame6 />
      <Frame111 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">16,000mi</p>
    </div>
  );
}

function Frame113() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame112() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame12 />
      <Frame113 />
    </div>
  );
}

function Frame332() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame110 />
      <Frame112 />
    </div>
  );
}

function MaskGroup4() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#212e58] from-[33.333%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#70a0d5]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame115() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Blue</p>
      <MaskGroup4 />
    </div>
  );
}

function Frame114() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame115 />
    </div>
  );
}

function Frame118() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame116() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame118 />
    </div>
  );
}

function Cta7() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">84% Match</p>
    </div>
  );
}

function Frame333() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta7 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame122() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group5() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group20() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group5 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame120() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame122 />
      <Group20 />
    </div>
  );
}

function Frame334() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame335() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame336() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame124() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame334 />
          <Frame335 />
          <Frame336 />
        </div>
      </div>
    </div>
  );
}

function Frame109() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame332 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame114 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame116 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame333 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame120 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame124 />
    </div>
  );
}

function BestDealBadge2() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame241() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <BestDealBadge2 />
    </div>
  );
}

function Frame281() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame282() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame242() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame281 />
      <Frame282 />
    </div>
  );
}

function Frame240() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame241 />
      <Frame242 />
    </div>
  );
}

function Frame36() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots4() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame37() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame126() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame36 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots4 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame37 />
        </div>
      </div>
    </div>
  );
}

function Card4() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer4 />
      <Frame109 />
      <Frame240 />
      <Frame126 />
    </div>
  );
}

function ImageContainer5() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[186px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[382px]" data-name="image 980">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage982} />
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px]">
        {`2023 Toyota Corolla `}
        <br aria-hidden="true" />
        Cross
      </p>
    </div>
  );
}

function Frame283() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$31,250</p>
    </div>
  );
}

function Frame136() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#06c] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame283 />
    </div>
  );
}

function Frame132() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame7 />
      <Frame136 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] w-[60px] whitespace-pre-wrap">18,000mi</p>
    </div>
  );
}

function Frame148() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame147() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame13 />
      <Frame148 />
    </div>
  );
}

function Frame337() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame132 />
      <Frame147 />
    </div>
  );
}

function MaskGroup5() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#f1f1f1] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#e9e9e9] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame150() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic White</p>
      <MaskGroup5 />
    </div>
  );
}

function Frame149() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame150 />
    </div>
  );
}

function Frame152() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame151() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame152 />
    </div>
  );
}

function Cta8() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">81% Match</p>
    </div>
  );
}

function Frame338() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta8 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame154() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group6() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group21() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group6 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame153() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame154 />
      <Group21 />
    </div>
  );
}

function Frame339() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame340() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame341() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame155() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame339 />
          <Frame340 />
          <Frame341 />
        </div>
      </div>
    </div>
  );
}

function Frame128() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame337 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame149 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame151 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame338 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame153 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame155 />
    </div>
  );
}

function PriceDropBadge2() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame244() {
  return (
    <div className="content-stretch flex items-center opacity-0 relative shrink-0">
      <PriceDropBadge2 />
    </div>
  );
}

function Frame284() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame285() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame245() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame284 />
      <Frame285 />
    </div>
  );
}

function Frame243() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame244 />
      <Frame245 />
    </div>
  );
}

function Frame38() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots5() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame39() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame156() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame38 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots5 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame39 />
        </div>
      </div>
    </div>
  );
}

function Card5() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer5 />
      <Frame128 />
      <Frame243 />
      <Frame156 />
    </div>
  );
}

function Frame94() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0 w-full">
      <Card3 />
      <Card4 />
      <Card5 />
    </div>
  );
}

function ImageContainer6() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[237px] left-[calc(50%+0.5px)] top-[calc(50%+10.5px)] w-[421px]" data-name="image 991">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[89.96%] left-[8.55%] max-w-none top-[5.02%] w-[82.9%]" src={imgImage991} />
        </div>
      </div>
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2024 Toyota RAV4</p>
        <p>Hybrid</p>
      </div>
    </div>
  );
}

function Frame286() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$33,500</p>
    </div>
  );
}

function Frame160() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame286 />
    </div>
  );
}

function Frame159() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame14 />
      <Frame160 />
    </div>
  );
}

function Frame15() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">5,000mi</p>
    </div>
  );
}

function Frame162() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame161() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame15 />
      <Frame162 />
    </div>
  );
}

function Frame342() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame159 />
      <Frame161 />
    </div>
  );
}

function MaskGroup6() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#212e58] from-[33.333%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#70a0d5]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame164() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Ocean Blue</p>
      <MaskGroup6 />
    </div>
  );
}

function Frame163() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame164 />
    </div>
  );
}

function Frame166() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame165() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame166 />
    </div>
  );
}

function Cta9() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0 w-[86.667px]" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">97% Match</p>
    </div>
  );
}

function Frame343() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta9 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame168() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group7() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group22() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group7 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame167() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame168 />
      <Group22 />
    </div>
  );
}

function Frame344() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame345() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame346() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame169() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame344 />
          <Frame345 />
          <Frame346 />
        </div>
      </div>
    </div>
  );
}

function Frame158() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame342 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame163 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame165 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame343 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame167 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame169 />
    </div>
  );
}

function BestDealBadge3() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center opacity-0 px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[18px]" data-name="Vector">
        <div className="absolute inset-[-1.67%_-1.11%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.4 12.4">
            <path clipRule="evenodd" d={svgPaths.p24d80400} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, white)" strokeWidth="0.4" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Low Price</p>
    </div>
  );
}

function Frame287() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame288() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame247() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame287 />
      <Frame288 />
    </div>
  );
}

function Frame246() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <BestDealBadge3 />
      <Frame247 />
    </div>
  );
}

function Frame40() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots6() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame41() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame170() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame40 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots6 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame41 />
        </div>
      </div>
    </div>
  );
}

function Card6() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer6 />
      <Frame158 />
      <Frame246 />
      <Frame170 />
    </div>
  );
}

function ImageContainer7() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[222px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[395px]" data-name="image 979">
        <img alt="" className="absolute inset-0 max-w-none object-contain pointer-events-none size-full" src={imgImage983} />
      </div>
    </div>
  );
}

function Frame16() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2020 Toyota Venza</p>
        <p>Limited Edition</p>
      </div>
    </div>
  );
}

function Frame289() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$32,000</p>
    </div>
  );
}

function Frame173() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame289 />
    </div>
  );
}

function Frame172() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame16 />
      <Frame173 />
    </div>
  );
}

function Frame17() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">9,000mi</p>
    </div>
  );
}

function Frame175() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame174() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame17 />
      <Frame175 />
    </div>
  );
}

function Frame347() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame172 />
      <Frame174 />
    </div>
  );
}

function MaskGroup7() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="col-1 mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px]" style={{ backgroundImage: "linear-gradient(171.656deg, rgb(104, 113, 120) 6.3953%, rgb(181, 190, 197) 145.59%)", maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame177() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Graphite</p>
      <MaskGroup7 />
    </div>
  );
}

function Frame176() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame177 />
    </div>
  );
}

function Frame181() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame178() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame181 />
    </div>
  );
}

function Cta10() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0 w-[86.667px]" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">74% Match</p>
    </div>
  );
}

function Frame348() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta10 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame185() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group8() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group23() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group8 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame182() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame185 />
      <Group23 />
    </div>
  );
}

function Frame349() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame350() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame351() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame186() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame349 />
          <Frame350 />
          <Frame351 />
        </div>
      </div>
    </div>
  );
}

function Frame171() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame347 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame176 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame178 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame348 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame182 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame186 />
    </div>
  );
}

function BestDealBadge4() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[14px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 14 12">
          <path d={svgPaths.p24247380} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Excellent Price</p>
    </div>
  );
}

function Frame249() {
  return (
    <div className="content-stretch flex items-center opacity-0 relative shrink-0">
      <BestDealBadge4 />
    </div>
  );
}

function Frame290() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame291() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame250() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame290 />
      <Frame291 />
    </div>
  );
}

function Frame248() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame249 />
      <Frame250 />
    </div>
  );
}

function Frame42() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots7() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame43() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame189() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame42 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots7 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame43 />
        </div>
      </div>
    </div>
  );
}

function Card7() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer7 />
      <Frame171 />
      <Frame248 />
      <Frame189 />
    </div>
  );
}

function ImageContainer8() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[178px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[510px]" data-name="image 983">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage984} />
      </div>
    </div>
  );
}

function Frame18() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2022 Toyota Yaris Cross</p>
        <p>Hybrid Active</p>
      </div>
    </div>
  );
}

function Frame292() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$24,250</p>
    </div>
  );
}

function Frame192() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame292 />
    </div>
  );
}

function Frame191() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame18 />
      <Frame192 />
    </div>
  );
}

function Frame19() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">11,050mi</p>
    </div>
  );
}

function Frame194() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame193() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame19 />
      <Frame194 />
    </div>
  );
}

function Frame352() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame191 />
      <Frame193 />
    </div>
  );
}

function MaskGroup8() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#ffed77] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#dcc200] via-[#caca00] via-[53.247%]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame196() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Sunrise Yellow</p>
      <MaskGroup8 />
    </div>
  );
}

function Frame195() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame196 />
    </div>
  );
}

function Frame198() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame197() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame198 />
    </div>
  );
}

function Cta11() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">72% Match</p>
    </div>
  );
}

function Frame353() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta11 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame200() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group9() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group24() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group9 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame199() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame200 />
      <Group24 />
    </div>
  );
}

function Frame354() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame355() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame356() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame201() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame354 />
          <Frame355 />
          <Frame356 />
        </div>
      </div>
    </div>
  );
}

function Frame190() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame352 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame195 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame197 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame353 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame199 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame201 />
    </div>
  );
}

function BestDealBadge5() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[18px]" data-name="Vector">
        <div className="absolute inset-[-1.67%_-1.11%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.4 12.4">
            <path clipRule="evenodd" d={svgPaths.p24d80400} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, white)" strokeWidth="0.4" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Low Price</p>
    </div>
  );
}

function Frame293() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame294() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame252() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame293 />
      <Frame294 />
    </div>
  );
}

function Frame251() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <BestDealBadge5 />
      <Frame252 />
    </div>
  );
}

function Frame44() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots8() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame45() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame202() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame44 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots8 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame45 />
        </div>
      </div>
    </div>
  );
}

function Card8() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer8 />
      <Frame190 />
      <Frame251 />
      <Frame202 />
    </div>
  );
}

function Frame157() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0 w-full">
      <Card6 />
      <Card7 />
      <Card8 />
    </div>
  );
}

function ImageContainer9() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[195px] left-[calc(50%+0.5px)] top-[calc(50%+10.5px)] w-[347px]" data-name="image 979">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage985} />
      </div>
    </div>
  );
}

function Frame20() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2025 Toyota RAV4</p>
        <p>Limited Edition</p>
      </div>
    </div>
  );
}

function Frame295() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$30,900</p>
    </div>
  );
}

function Frame206() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame295 />
    </div>
  );
}

function Frame205() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame20 />
      <Frame206 />
    </div>
  );
}

function Frame21() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">15,000mi</p>
    </div>
  );
}

function Frame208() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame207() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame21 />
      <Frame208 />
    </div>
  );
}

function Frame357() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame205 />
      <Frame207 />
    </div>
  );
}

function MaskGroup9() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#c4c2c2] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#817d7d] via-[53.247%] via-white" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame210() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Gray</p>
      <MaskGroup9 />
    </div>
  );
}

function Frame209() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame210 />
    </div>
  );
}

function Frame212() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame211() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame212 />
    </div>
  );
}

function Cta12() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0 w-[86.667px]" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">55% Match</p>
    </div>
  );
}

function Frame358() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta12 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame214() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group10() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group25() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group10 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame213() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame214 />
      <Group25 />
    </div>
  );
}

function Frame359() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame360() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame361() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame215() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame359 />
          <Frame360 />
          <Frame361 />
        </div>
      </div>
    </div>
  );
}

function Frame204() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame357 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame209 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame211 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame358 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame213 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame215 />
    </div>
  );
}

function BestDealBadge6() {
  return (
    <div className="bg-[#12b45d] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[8px] py-[5px] relative rounded-[4px] shrink-0" data-name="Best Deal Badge">
      <div className="h-[12px] relative shrink-0 w-[18px]" data-name="Vector">
        <div className="absolute inset-[-1.67%_-1.11%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 18.4 12.4">
            <path clipRule="evenodd" d={svgPaths.p24d80400} fill="var(--fill-0, white)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, white)" strokeWidth="0.4" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Low Price</p>
    </div>
  );
}

function Frame296() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame297() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame254() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame296 />
      <Frame297 />
    </div>
  );
}

function Frame253() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <BestDealBadge6 />
      <Frame254 />
    </div>
  );
}

function Frame46() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots9() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame47() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame216() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame46 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots9 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame47 />
        </div>
      </div>
    </div>
  );
}

function Card9() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer9 />
      <Frame204 />
      <Frame253 />
      <Frame216 />
    </div>
  );
}

function ImageContainer10() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[195px] left-[calc(50%+0.5px)] top-[calc(50%+10.5px)] w-[347px]" data-name="image 980">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage986} />
      </div>
    </div>
  );
}

function Frame22() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <div className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px] whitespace-nowrap">
        <p className="mb-0">2020 Toyota Corolla Cross</p>
        <p>Limited Edition</p>
      </div>
    </div>
  );
}

function Frame298() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$31,250</p>
    </div>
  );
}

function Frame219() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic relative shrink-0 text-[#58595b] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame298 />
    </div>
  );
}

function Frame218() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame22 />
      <Frame219 />
    </div>
  );
}

function Frame23() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] w-[62px] whitespace-pre-wrap">17,200mi</p>
    </div>
  );
}

function Frame221() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame220() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame23 />
      <Frame221 />
    </div>
  );
}

function Frame362() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame218 />
      <Frame220 />
    </div>
  );
}

function MaskGroup10() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#4a5567] from-[4.167%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#75879f] via-[#bdcbd7] via-[53.247%]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame223() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Pastel Blue</p>
      <MaskGroup10 />
    </div>
  );
}

function Frame222() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame223 />
    </div>
  );
}

function Frame225() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame224() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame225 />
    </div>
  );
}

function Cta13() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0 w-[86.667px]" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">98% Match</p>
    </div>
  );
}

function Frame363() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta13 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame227() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group11() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group26() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group11 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame226() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame227 />
      <Group26 />
    </div>
  );
}

function Frame364() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame365() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame366() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame228() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame364 />
          <Frame365 />
          <Frame366 />
        </div>
      </div>
    </div>
  );
}

function Frame217() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame362 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame222 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame224 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame363 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame226 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame228 />
    </div>
  );
}

function PriceDropBadge3() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame256() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <PriceDropBadge3 />
    </div>
  );
}

function Frame299() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame300() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame257() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame299 />
      <Frame300 />
    </div>
  );
}

function Frame255() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame256 />
      <Frame257 />
    </div>
  );
}

function Frame48() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots10() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame49() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame258() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame48 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots10 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame49 />
        </div>
      </div>
    </div>
  );
}

function Card10() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer10 />
      <Frame217 />
      <Frame255 />
      <Frame258 />
    </div>
  );
}

function ImageContainer11() {
  return (
    <div className="h-[312px] overflow-clip relative shrink-0 w-full" data-name="Image Container">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute h-[190px] left-[calc(50%+7.5px)] top-[calc(50%+10.5px)] w-[339px]" data-name="image 979">
        <img alt="" className="absolute inset-0 max-w-none object-cover pointer-events-none size-full" src={imgImage979} />
      </div>
    </div>
  );
}

function Frame24() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0">
      <p className="font-['Toyota_Type:Bold',sans-serif] leading-[22px] not-italic relative shrink-0 text-[#111] text-[16px]">
        {`2023 Toyota Corolla `}
        <br aria-hidden="true" />
        Cross
      </p>
    </div>
  );
}

function Frame301() {
  return (
    <div className="content-stretch flex items-center justify-end relative shrink-0 w-full">
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#eb0d1c] text-[20px] text-right">$31,250</p>
    </div>
  );
}

function Frame261() {
  return (
    <div className="content-stretch flex flex-col gap-[8px] items-end py-[2px] relative self-stretch shrink-0 w-[94px]">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[0] not-italic opacity-0 relative shrink-0 text-[#06c] text-[0px] text-[12px]">
        <span className="leading-[normal]">{`was `}</span>
        <span className="leading-[normal]">$35,900</span>
      </p>
      <Frame301 />
    </div>
  );
}

function Frame260() {
  return (
    <div className="content-stretch flex items-start justify-between py-[4px] relative shrink-0 w-[384px]">
      <Frame24 />
      <Frame261 />
    </div>
  );
}

function Frame25() {
  return (
    <div className="content-stretch flex gap-[6px] items-center relative shrink-0">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none rotate-180">
          <div className="relative size-[14px]" data-name="Vector">
            <div className="absolute inset-[-1.43%]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14.4 14.4">
                <path clipRule="evenodd" d={svgPaths.p14bde00} fill="var(--fill-0, #58595B)" fillRule="evenodd" id="Vector" stroke="var(--stroke-0, #58595B)" strokeWidth="0.4" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">18,000mi</p>
    </div>
  );
}

function Frame263() {
  return (
    <div className="content-stretch flex items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#547dd5] text-[14px] text-right">Est. $583/mo</p>
    </div>
  );
}

function Frame262() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame25 />
      <Frame263 />
    </div>
  );
}

function Frame367() {
  return (
    <div className="content-stretch flex flex-col gap-[4px] items-start relative shrink-0">
      <Frame260 />
      <Frame262 />
    </div>
  );
}

function MaskGroup11() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0" data-name="Mask group">
      <div className="bg-gradient-to-b col-1 from-[#2e0507] from-[33.333%] mask-alpha mask-intersect mask-no-clip mask-no-repeat mask-position-[0px_0px] mask-size-[24px_24px] ml-0 mt-0 rounded-[4px] row-1 size-[24px] to-[#ff3b42]" style={{ maskImage: `url('${imgRectangle14593}')` }} />
    </div>
  );
}

function Frame265() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Metallic Red</p>
      <MaskGroup11 />
    </div>
  );
}

function Frame264() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Exterior:</p>
      <Frame265 />
    </div>
  );
}

function Frame267() {
  return (
    <div className="content-stretch flex gap-[12px] items-center relative shrink-0">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[32px] not-italic relative shrink-0 text-[#58595b] text-[14px] text-right">Gray Fabric</p>
      <div className="bg-[#3f3f3f] rounded-[4px] shrink-0 size-[24px]" />
    </div>
  );
}

function Frame266() {
  return (
    <div className="content-stretch flex items-center justify-between relative shrink-0 w-[384px]">
      <p className="font-['Toyota_Type_Regular:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px]">Interior:</p>
      <Frame267 />
    </div>
  );
}

function Cta14() {
  return (
    <div className="bg-black content-stretch flex gap-[6px] h-[24px] items-center justify-center px-[7px] py-[5px] relative rounded-[4px] shrink-0" data-name="CTA">
      <div className="h-[12px] relative shrink-0 w-[13px]" data-name="Vector">
        <div className="absolute inset-[-4.17%_-3.85%]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 14 13">
            <path d={svgPaths.pa275980} id="Vector" stroke="var(--stroke-0, white)" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </div>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">99% Match</p>
    </div>
  );
}

function Frame368() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex items-center justify-between px-[16px] relative w-full">
          <Cta14 />
          <p className="[text-decoration-skip-ink:none] decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[1.15] not-italic relative shrink-0 text-[#111] text-[14px] text-right underline">Refine your search</p>
        </div>
      </div>
    </div>
  );
}

function Frame303() {
  return (
    <div className="content-stretch flex items-center relative shrink-0 w-[384px]">
      <p className="decoration-solid font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] underline">Toyota of Fort Worth</p>
    </div>
  );
}

function Group12() {
  return (
    <div className="col-1 h-[12px] ml-0 mt-0 relative row-1 w-[9.6px]">
      <div className="absolute inset-[-5.56%_-6.94%]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 10.9335 13.3333">
          <g id="Group 2">
            <path d={svgPaths.p28c7bb80} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
            <path d={svgPaths.p5c961a0} id="Vector_2" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.33333" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group27() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <Group12 />
      <p className="col-1 font-['Toyota_Type:Regular',sans-serif] leading-[normal] ml-[15.6px] mt-px not-italic relative row-1 text-[#58595b] text-[14px]">6.1mi</p>
    </div>
  );
}

function Frame302() {
  return (
    <div className="content-stretch flex h-[24px] items-center justify-between relative shrink-0 w-[384px]">
      <Frame303 />
      <Group27 />
    </div>
  );
}

function Frame369() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center min-h-px min-w-px relative">
      <div className="h-[16px] relative shrink-0 w-[12px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 12 16">
          <path d={svgPaths.p35db0100} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Warranty</p>
    </div>
  );
}

function Frame370() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-center min-h-px min-w-px relative">
      <div className="relative shrink-0 size-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <path d={svgPaths.p2e3e4f00} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">Inspected</p>
    </div>
  );
}

function Frame371() {
  return (
    <div className="content-stretch flex flex-[1_0_0] gap-[6px] items-center justify-end min-h-px min-w-px relative">
      <div className="h-[14px] relative shrink-0 w-[15px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 15 14">
          <path d={svgPaths.p25344740} fill="var(--fill-0, #58595B)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[#58595b] text-[14px] text-center">1 Owner</p>
    </div>
  );
}

function Frame304() {
  return (
    <div className="h-[23px] relative shrink-0 w-full">
      <div className="flex flex-row items-center size-full">
        <div className="content-stretch flex gap-[16px] items-center px-[16px] relative size-full">
          <Frame369 />
          <Frame370 />
          <Frame371 />
        </div>
      </div>
    </div>
  );
}

function Frame259() {
  return (
    <div className="content-stretch flex flex-col gap-[12px] items-center pb-[12px] relative shrink-0 w-full">
      <div className="bg-black h-px opacity-10 shrink-0 w-full" />
      <Frame367 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame264 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame266 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame368 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame302 />
      <div className="flex h-px items-center justify-center relative shrink-0 w-[416px]" style={{ "--transform-inner-width": "1184.796875", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-90">
          <div className="bg-black h-[416px] opacity-10 w-px" />
        </div>
      </div>
      <Frame304 />
    </div>
  );
}

function PriceDropBadge4() {
  return (
    <div className="bg-[#06c] content-stretch flex gap-[7px] h-[24px] items-center justify-center px-[9px] py-[5px] relative rounded-[4px] shrink-0 w-[84px]" data-name="Price Drop Badge">
      <div className="relative shrink-0 size-[13px]" data-name="Vector">
        <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 13 13">
          <path d={svgPaths.p31fd6100} fill="var(--fill-0, white)" id="Vector" />
        </svg>
      </div>
      <p className="font-['Toyota_Type:Semibold',sans-serif] leading-[normal] not-italic relative shrink-0 text-[10px] text-center text-white">Price Drop</p>
    </div>
  );
}

function Frame306() {
  return (
    <div className="content-stretch flex items-center opacity-0 relative shrink-0">
      <PriceDropBadge4 />
    </div>
  );
}

function Frame308() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872282">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.p22081e00} fill="var(--fill-0, #58595B)" id="Union" />
        </g>
      </svg>
    </div>
  );
}

function Frame309() {
  return (
    <div className="relative shrink-0 size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 36 36">
        <g id="Frame 1618872283">
          <rect fill="var(--fill-0, white)" height="36" rx="18" width="36" />
          <path d={svgPaths.pff6dd00} id="Vector" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame307() {
  return (
    <div className="content-stretch flex h-[24px] items-center relative shrink-0">
      <Frame308 />
      <Frame309 />
    </div>
  );
}

function Frame305() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 pt-[16px] px-[16px] top-0 w-[416px]">
      <Frame306 />
      <Frame307 />
    </div>
  );
}

function Frame50() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871805" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Dots11() {
  return (
    <div className="h-[6px] relative w-[48px]" data-name="dots">
      <div className="absolute inset-[-66.67%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 48 14">
          <g id="dots">
            <ellipse cx="3" cy="7" fill="var(--fill-0, black)" id="Ellipse 17" opacity="0.3" rx="3" ry="3" />
            <ellipse cx="17" cy="7" fill="var(--fill-0, black)" id="Ellipse 14" opacity="0.3" rx="3" ry="3" />
            <g id="Frame 1618872271">
              <ellipse cx="31" cy="7" fill="var(--fill-0, black)" id="Ellipse 16" rx="3" ry="3" />
              <path d={svgPaths.p358f7af1} id="Ellipse 18" stroke="var(--stroke-0, black)" />
            </g>
            <ellipse cx="45" cy="7" fill="var(--fill-0, black)" id="Ellipse 15" opacity="0.3" rx="3" ry="3" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame51() {
  return (
    <div className="relative size-[36px]">
      <svg className="absolute block inset-0" fill="none" preserveAspectRatio="none" viewBox="0 0 32 32">
        <g id="Frame 1618871806" opacity="0">
          <rect fill="var(--fill-0, white)" height="35" rx="17.5" width="35" x="0.5" y="0.5" />
          <rect height="35" rx="17.5" stroke="var(--stroke-0, #E6E6E6)" width="35" x="0.5" y="0.5" />
          <path d="M20 24L14 18L20 12" id="Icon" stroke="var(--stroke-0, #58595B)" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame310() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex items-center justify-between left-1/2 opacity-0 top-[269px] w-[384px]">
      <div className="flex items-center justify-center relative shrink-0">
        <div className="-scale-y-100 flex-none">
          <Frame50 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Dots11 />
        </div>
      </div>
      <div className="flex items-center justify-center relative shrink-0">
        <div className="flex-none rotate-180">
          <Frame51 />
        </div>
      </div>
    </div>
  );
}

function Card11() {
  return (
    <div className="bg-white content-stretch flex flex-col items-start overflow-clip relative rounded-[8px] shrink-0 w-[416px]" data-name="Card">
      <ImageContainer11 />
      <Frame259 />
      <Frame305 />
      <Frame310 />
    </div>
  );
}

function Frame203() {
  return (
    <div className="content-stretch flex gap-[16px] items-start relative shrink-0 w-full">
      <Card9 />
      <Card10 />
      <Card11 />
    </div>
  );
}

function Frame322() {
  return (
    <div className="-translate-x-1/2 absolute content-stretch flex flex-col gap-[16px] items-start left-1/2 top-[380px] w-[1280px]">
      <Frame53 />
      <Frame94 />
      <Frame157 />
      <Frame203 />
    </div>
  );
}

export default function SearchPageFull() {
  return (
    <div className="bg-[#f4f4f4] relative size-full" data-name="Search Page - Full">
      <div className="-translate-x-1/2 absolute bg-gradient-to-t from-[#f4f4f4] h-[240px] left-1/2 to-[rgba(244,244,244,0)] top-[90px] w-[1440px]" />
      <div className="-translate-x-1/2 absolute bg-black h-px left-1/2 opacity-10 top-[249px] w-[1440px]" />
      <Frame183 />
      <p className="absolute font-['Toyota_Type:Bold',sans-serif] leading-[56px] left-[80px] not-italic text-[#111] text-[32px] top-[119px] tracking-[-0.4492px] uppercase w-[378px] whitespace-pre-wrap">Find your next Car</p>
      <p className="absolute font-['Toyota_Type:Regular',sans-serif] leading-[normal] left-[80px] not-italic text-[15px] text-black top-[158px]">1,784,503 Vehicles Available</p>
      <NavigationD />
      <Frame184 />
      <Frame180 />
      <Frame179 />
      <Group14 />
      <Frame322 />
    </div>
  );
}