
  # Design Next.js Page

  This is a code bundle for Design Next.js Page. The original project is available at https://www.figma.com/design/Y2MpFaYGchFIgzfIuD0IUB/Design-Next.js-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  