import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import SearchPageFull from './pages/SearchPageFull';
function App() {
  return (
    <BrowserRouter>
        <Routes>
			<Route path="/" element={<SearchPageFull />} />
			<Route path="/SearchPageFull" element={<SearchPageFull />} />
        </Routes>
    </BrowserRouter>
  );
}
export default App;