import React from "react";
export default (props) => {
	return (
		<div className="flex flex-col bg-white">
			<div className="self-stretch bg-[#F4F4F4] pt-[18px]">
				<div className="flex items-center self-stretch py-0.5 mb-[30px] mx-20">
					<div className="flex shrink-0 items-center gap-4">
						<img
							src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/bx3wq0mf_expires_30_days.png"} 
							className="w-10 h-10 object-fill"
						/>
						<div className="flex flex-col shrink-0 items-start pb-[1px]">
							<span className="text-black text-lg font-bold" >
								{"ARROW"}
							</span>
						</div>
					</div>
					<div className="flex-1 self-stretch">
					</div>
					<span className="text-[#111111] text-sm mr-[139px]" >
						{"Buy                Sell                Finance                Why Arrow"}
					</span>
					<div className="flex shrink-0 items-center gap-[27px]">
						<div className="flex shrink-0 items-center gap-1.5">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ubpf6fzm_expires_30_days.png"} 
								className="w-2.5 h-[13px] object-fill"
							/>
							<span className="text-[#111111] text-sm" >
								{"Buffalo, WV 25033"}
							</span>
						</div>
						<div className="flex shrink-0 items-center gap-4">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/kvc6t06q_expires_30_days.png"} 
								className="w-10 h-10 object-fill"
							/>
							<div className="flex shrink-0 items-center py-[9px] px-[11px] gap-3 rounded-[100px] border border-solid border-black">
								<div className="flex flex-col shrink-0 items-start bg-[#EB0A1E] py-0.5 px-[7px] rounded-[40px]">
									<span className="text-white text-sm font-bold" >
										{"S"}
									</span>
								</div>
								<span className="text-[#111111] text-sm font-bold" >
									{"Sarah..."}
								</span>
							</div>
						</div>
					</div>
				</div>
				<div className="flex flex-col items-start self-stretch relative mb-[50px]">
					<div className="flex flex-col items-start self-stretch pt-[26px]" 
						style={{
							background: "linear-gradient(180deg, #F4F4F4, #F4F4F400)"
						}}>
						<div className="flex justify-between items-center self-stretch mb-6 mx-20">
							<div className="flex flex-col shrink-0 items-start gap-4">
								<span className="text-[#111111] text-[32px] font-bold" >
									{"Find your next Car"}
								</span>
								<span className="text-black text-[15px] mr-[126px]" >
									{"1,784,503 Vehicles Available"}
								</span>
							</div>
							<div className="flex shrink-0 items-center bg-white py-2 rounded-[100px]">
								<div className="flex shrink-0 items-center ml-5 mr-[466px] gap-2">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/r2zkqu4i_expires_30_days.png"} 
										className="w-[19px] h-[19px] object-fill"
									/>
									<span className="text-black text-[15px]" >
										{"SUV under 35k with low miles"}
									</span>
								</div>
								<div className="flex shrink-0 items-center mr-2 gap-[15px]">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/gg5ml05b_expires_30_days.png"} 
										className="w-2.5 h-4 object-fill"
									/>
									<button className="flex flex-col shrink-0 items-start bg-[#FF0202] text-left py-2.5 px-[23px] rounded-[100px] border-0"
										onClick={()=>alert("Pressed!")}>
										<span className="text-white text-sm font-bold" >
											{"Search"}
										</span>
									</button>
								</div>
							</div>
						</div>
						<div className="flex flex-col items-end self-stretch mb-6">
							<div className="flex items-center mr-20 gap-2">
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Off-road"}
									</span>
								</button>
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Eco-friendly"}
									</span>
								</button>
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"High safety rating"}
									</span>
								</button>
								<button className="flex flex-col shrink-0 items-start bg-white text-left p-2.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Near me"}
									</span>
								</button>
							</div>
						</div>
						<div className="self-stretch bg-black h-[1px] mb-8">
						</div>
						<div className="flex justify-between items-start self-stretch max-w-[1228px] mb-1.5 ml-[132px] mr-20">
							<span className="text-[#111111] text-base font-bold mt-[13px]" >
								{"247 vehicles found"}
							</span>
							<div className="flex shrink-0 items-center gap-1">
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"SUV"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/f2stx6yq_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-[5px] rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"$30k-40k"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/xwq23xj2_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Heated Seats"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/lgs8bx4u_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Under 50k mi"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/btt8x40w_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-[7px] rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"Leather Seats"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/l3i6d6ea_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"4 Doors"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fhpuc6d4_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
								<button className="flex shrink-0 items-center bg-transparent text-left py-2.5 px-2 gap-1.5 rounded-[100px] border border-solid border-[#0000001A]"
									onClick={()=>alert("Pressed!")}>
									<span className="text-black text-xs" >
										{"2023 or newer"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/oksbsxbl_expires_30_days.png"} 
										className="w-2 h-2 rounded-[100px] object-fill"
									/>
								</button>
							</div>
						</div>
						<img
							src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/0w9juv0n_expires_30_days.png"} 
							className="w-[11px] h-1.5 ml-[276px] object-fill"
						/>
					</div>
					<button className="flex flex-col items-start bg-[#FF0202] text-left absolute bottom-[-5px] left-20 p-3 rounded-[100px] border-0"
						onClick={()=>alert("Pressed!")}>
						<img
							src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/c8gbvkcf_expires_30_days.png"} 
							className="w-4 h-4 object-fill"
						/>
					</button>
					<span className="text-[#121212] text-xs font-bold absolute bottom-[-4px] left-[133px]" >
						{"Sort by: Recommended"}
					</span>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] left-[505px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"Sunroof"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9j5skttj_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] left-[587px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-[11px]">
							<span className="text-black text-xs" >
								{"4WD"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/7kqudjfg_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<div className="flex flex-col items-center self-stretch absolute bottom-[-18px] right-0 left-0">
						<button className="flex items-center bg-transparent text-left py-2.5 px-2 gap-[11px] rounded-[100px] border border-solid border-[#0000001A]"
							onClick={()=>alert("Pressed!")}>
							<span className="text-black text-xs" >
								{"Leather Seats"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/p98qcw7x_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</button>
					</div>
					<div className="flex flex-col items-center self-stretch absolute bottom-[-18px] right-0 left-0">
						<button className="flex items-center bg-transparent text-left py-2.5 px-2 gap-[11px] rounded-[100px] border border-solid border-[#0000001A]"
							onClick={()=>alert("Pressed!")}>
							<span className="text-black text-xs" >
								{"Hybrid"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/8437q35e_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</button>
					</div>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[485px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"Apple Carplay"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/q0zhtih5_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[382px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"Hands-Free"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/u1c7a4lz_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[261px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-2.5">
							<span className="text-black text-xs" >
								{"LED Highlights"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/grcwobff_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-transparent text-left absolute bottom-[-18px] right-[148px] py-2.5 px-2 rounded-[100px] border border-solid border-[#0000001A]"
						onClick={()=>alert("Pressed!")}>
						<div className="flex items-center gap-[11px]">
							<span className="text-black text-xs" >
								{"LED Taillights"}
							</span>
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/k991g920_expires_30_days.png"} 
								className="w-2 h-2 rounded-[100px] object-fill"
							/>
						</div>
					</button>
					<button className="flex flex-col items-start bg-black text-left absolute bottom-[-18px] right-20 py-2.5 px-4 rounded-[100px] border-0"
						onClick={()=>alert("Pressed!")}>
						<span className="text-white text-xs" >
							{"Reset"}
						</span>
					</button>
				</div>
				<div className="flex flex-col self-stretch mb-20 mx-20 gap-4">
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[84px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/qatsg1eo_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-[11px] mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#111111] text-base font-bold w-[151px]" >
											{"2023 Toyota Corolla  Cross"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-0.5 pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/023gz4uh_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"18,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-[13px]">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Red"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/pvoorqri_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/d9to0cjj_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"99% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/5lppsf96_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/8l9h01g6_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/5xye8r2o_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/jb7zd0eu_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/c0u8jp8o_expires_30_days.png"} 
											className="w-3.5 h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Excellent Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9ebbwdpr_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-[11px] mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2022 Toyota RAV4 Hybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-0.5 pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/l3goarak_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"24,600mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-[13px]">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic White"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2o1nlkbf_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/48cnosv1_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"98% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9lzdk01g_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/s7gdxa5i_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/vpry7ihv_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/4496xfxi_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#0066CC] text-left py-[5px] px-[7px] gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/an5vfose_expires_30_days.png"} 
											className="w-[13px] h-[13px] rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Price Drop"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/77y6ja4x_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-[11px] mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2023 Toyota RAV4\nHybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start py-0.5 gap-2">
										<span className="text-[#58595B] text-xs ml-[23px]" >
											{"was $34,900"}
										</span>
										<div className="flex flex-col items-start pl-[17px] pr-0.5">
											<span className="text-[#EB0D1C] text-xl font-bold" >
												{"$33,250"}
											</span>
										</div>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ubz1sjwk_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"21,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pb-[1px]">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-[13px]">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ulwvkgl8_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/c5wad3di_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"78% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/l1fe61q5_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/1stpl8mu_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/cymq11tu_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/xhybvaoc_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="bg-[#0E5B32] w-[90px] h-6 rounded">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/oapqmutr_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2024 Toyota RAV4 Hybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$29,990"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/sm13qgha_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"24,500mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic White"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2akq6tx9_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/s1kl4y7z_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"85% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yfpekrcg_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/cloa92lk_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/41bgetoq_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6qeciw5x_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/bsiov48j_expires_30_days.png"} 
											className="w-3.5 h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Excellent Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/1yimc3xz_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-44" >
											{"2022 Toyota Yaris Cross\nHybrid Active"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$30,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ankj0ax5_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"16,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/pb1f2v0y_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ha5ekvfc_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"84% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/v7u77l0q_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/x5htr4s0_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/d39qrjqi_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ntnj5imt_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[84px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ye5shgay_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[151px]" >
											{"2023 Toyota Corolla  Cross"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/4rf6vi44_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"18,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic White"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/3qnypjqm_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/i6cue7i3_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"81% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/6fghojsk_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/cj154jcp_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ek56pl4f_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ow5dhysb_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="bg-[#12B45D] w-[87px] h-6 rounded">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/384g9fsn_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2024 Toyota RAV4\nHybrid"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$33,500"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/hjimyh87_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"5,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Ocean Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ks8n7248_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/oj8acvw7_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"97% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/vmx6zp79_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/w936ze2e_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/jc5meyzi_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ks01r79a_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[107px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/gmqz390m_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[140px]" >
											{"2020 Toyota Venza\nLimited Edition"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$32,000"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2qco43nx_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"9,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Graphite"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/vxluje2y_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/0irg6cr7_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"74% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/1z1td5s0_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/bz09klba_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/l25a2emo_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ufpypfe8_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/jmib67gt_expires_30_days.png"} 
											className="w-[18px] h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Low Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ne7hhpez_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-44" >
											{"2022 Toyota Yaris Cross\nHybrid Active"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$24,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ob9hp8o3_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"11,050mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Sunrise Yellow"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/i85emb7y_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yk2tuvfh_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"72% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fvrez2p5_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/tsnu6iiv_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yi0czypx_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/rao2y7c1_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
					<div className="flex items-center self-stretch gap-4">
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#12B45D] text-left py-1.5 px-2 gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/v32f3g0y_expires_30_days.png"} 
											className="w-[18px] h-3 rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Low Price"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ss0go143_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[136px]" >
											{"2025 Toyota RAV4\nLimited Edition"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[17px] pr-0.5">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$30,900"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/tc7hhk70_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"15,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Gray"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/2a00bay0_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/1d4c3xm0_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"55% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/r4x6i1k9_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/es5o0hls_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/p3nkqplb_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/7qdrq31w_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<button className="flex shrink-0 items-center bg-[#0066CC] text-left py-[5px] px-[7px] gap-[7px] rounded border-0"
										onClick={()=>alert("Pressed!")}>
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/hp6wm41n_expires_30_days.png"} 
											className="w-[13px] h-[13px] rounded object-fill"
										/>
										<span className="text-white text-[10px] font-bold" >
											{"Price Drop"}
										</span>
									</button>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/hnpl5r1d_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[197px]" >
											{"2020 Toyota Corolla Cross\nLimited Edition"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start py-[1px] gap-[7px]">
										<span className="text-[#58595B] text-xs ml-[23px]" >
											{"was $35,900"}
										</span>
										<div className="flex flex-col items-start pl-[19px] pr-[3px]">
											<span className="text-[#EB0D1C] text-xl font-bold" >
												{"$31,250"}
											</span>
										</div>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/v9d5l3n4_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"17,200mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Pastel Blue"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/xv0xbgh7_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/d1fjqw2d_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"98% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/oxmzjwiq_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/ivikjdb2_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/40pf26dq_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/apqpmc9k_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[1px]" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex-1 bg-white pb-3 rounded-lg">
							<div className="self-stretch mb-3">
								<div className="flex justify-between items-start self-stretch pt-4 px-4 mb-[228px]">
									<div className="w-[84px] h-6">
									</div>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/jyrwtp03_expires_30_days.png"} 
										className="w-[72px] h-6 object-fill"
									/>
								</div>
								<div className="self-stretch h-9 mb-[7px] mx-4">
								</div>
								<div className="self-stretch bg-black h-[1px]">
								</div>
							</div>
							<div className="flex flex-col self-stretch mb-3 mx-4 gap-1">
								<div className="flex justify-between items-center self-stretch py-1">
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#111111] text-base font-bold w-[151px]" >
											{"2023 Toyota Corolla  Cross"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start pt-[19px] pb-[1px] pl-[19px] pr-[3px]">
										<span className="text-[#EB0D1C] text-xl font-bold" >
											{"$31,250"}
										</span>
									</div>
								</div>
								<div className="flex justify-between items-center self-stretch py-[5px]">
									<div className="flex shrink-0 items-center gap-1.5">
										<img
											src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/fxi54upf_expires_30_days.png"} 
											className="w-3.5 h-3.5 object-fill"
										/>
										<span className="text-[#58595B] text-sm" >
											{"18,000mi"}
										</span>
									</div>
									<div className="flex flex-col shrink-0 items-start">
										<span className="text-[#547DD5] text-sm" >
											{"Est. $583/mo"}
										</span>
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-[11px] mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Exterior:"}
								</span>
								<div className="flex shrink-0 items-center gap-[15px]">
									<span className="text-[#58595B] text-sm" >
										{"Metallic Red"}
									</span>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/yyx4mndg_expires_30_days.png"} 
										className="w-6 h-6 object-fill"
									/>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Interior:"}
								</span>
								<div className="flex shrink-0 items-center gap-3.5">
									<span className="text-[#58595B] text-sm" >
										{"Gray Fabric"}
									</span>
									<div className="bg-[#3F3F3F] w-6 h-6 rounded">
									</div>
								</div>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-between items-center self-stretch px-4 mb-3">
								<button className="flex shrink-0 items-center bg-black text-left py-1.5 px-[7px] gap-1.5 rounded border-0"
									onClick={()=>alert("Pressed!")}>
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/494ce4al_expires_30_days.png"} 
										className="w-[13px] h-3 rounded object-fill"
									/>
									<span className="text-white text-[10px] font-bold" >
										{"99% Match"}
									</span>
								</button>
								<span className="text-[#111111] text-sm" >
									{"Refine your search"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex items-center self-stretch py-1.5 mb-3 mx-4">
								<span className="text-[#58595B] text-sm" >
									{"Toyota of Fort Worth"}
								</span>
								<div className="flex-1 self-stretch">
								</div>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/496w55sh_expires_30_days.png"} 
									className="w-[9px] h-3 mr-1.5 object-fill"
								/>
								<span className="text-[#58595B] text-sm" >
									{"6.1mi"}
								</span>
							</div>
							<div className="self-stretch bg-black h-[1px] mb-3">
							</div>
							<div className="flex justify-center items-center self-stretch py-[3px] gap-4">
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/t9bahuzl_expires_30_days.png"} 
										className="w-3 h-4 mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm mr-[39px]" >
										{"Warranty"}
									</span>
								</div>
								<div className="flex shrink-0 items-center px-[15px] gap-1.5">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/r743zemb_expires_30_days.png"} 
										className="w-[15px] h-[15px] object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"Inspected"}
									</span>
								</div>
								<div className="flex shrink-0 items-center">
									<img
										src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/v6uxygtu_expires_30_days.png"} 
										className="w-[15px] h-3.5 ml-[42px] mr-1.5 object-fill"
									/>
									<span className="text-[#58595B] text-sm" >
										{"1 Owner"}
									</span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div className="self-stretch bg-[#1A1A1A] py-[54px]">
					<div className="flex items-start self-stretch max-w-[1189px] mb-[65px] ml-20 mr-[171px]">
						<div className="flex-1 mr-[54px]">
							<div className="flex flex-col items-start self-stretch pb-[1px] mb-4">
								<span className="text-[#EB0A1E] text-2xl font-bold" >
									{"Arrow"}
								</span>
							</div>
							<div className="flex flex-col items-start self-stretch pt-[1px] mb-[15px]">
								<span className="text-[#99A1AE] text-sm w-[179px]" >
									{"Your trusted partner for quality pre-owned vehicles."}
								</span>
							</div>
							<div className="flex items-center self-stretch gap-3">
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/0atqglvx_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/4hsagoze_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/1wbqf657_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
								<img
									src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/sh2czpb5_expires_30_days.png"} 
									className="w-[35px] h-[35px] object-fill"
								/>
							</div>
						</div>
						<div className="flex flex-1 flex-col mr-[55px] gap-4">
							<div className="flex flex-col items-start self-stretch">
								<span className="text-white text-lg font-bold" >
									{"Shop"}
								</span>
							</div>
							<div className="self-stretch pb-[33px]">
								<div className="flex flex-col items-start self-stretch py-[3px] mb-2">
									<span className="text-[#99A1AE] text-sm" >
										{"Buy a Car"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Sell Your Car"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Finance Options"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Trade-In Value"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex flex-1 flex-col mr-[54px] gap-4">
							<div className="flex flex-col items-start self-stretch">
								<span className="text-white text-lg font-bold" >
									{"Support"}
								</span>
							</div>
							<div className="self-stretch pb-[1px]">
								<div className="flex flex-col items-start self-stretch py-[3px] mb-2">
									<span className="text-[#99A1AE] text-sm" >
										{"Contact Us"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"FAQs"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Financing Help"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Returns & Exchanges"}
									</span>
								</div>
								<div className="self-stretch h-[23px]">
								</div>
							</div>
						</div>
						<div className="flex flex-1 flex-col mr-[55px] gap-4">
							<div className="flex flex-col items-start self-stretch">
								<span className="text-white text-lg font-bold" >
									{"Company"}
								</span>
							</div>
							<div className="self-stretch pb-[1px]">
								<div className="flex flex-col items-start self-stretch py-[3px] mb-2">
									<span className="text-[#99A1AE] text-sm" >
										{"About Arrow"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Press"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Partnerships"}
									</span>
								</div>
								<div className="flex flex-col items-start self-stretch py-[3px] mb-[9px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Locations"}
									</span>
								</div>
								<div className="self-stretch h-[23px] py-[3px]">
								</div>
							</div>
						</div>
						<div className="flex flex-col shrink-0 items-start">
							<span className="text-white text-lg font-bold mb-5 mr-[58px]" >
								{"Legal"}
							</span>
							<div className="flex flex-col items-start mb-4 mr-[18px]">
								<span className="text-[#99A1AE] text-sm" >
									{"Privacy Policy"}
								</span>
							</div>
							<div className="flex flex-col items-start mb-4">
								<span className="text-[#99A1AE] text-sm" >
									{"Terms of Service"}
								</span>
							</div>
							<div className="flex flex-col items-start mb-4 mr-[18px]">
								<span className="text-[#99A1AE] text-sm" >
									{"Cookie Policy"}
								</span>
							</div>
							<div className="flex flex-col items-start mb-4 mr-6">
								<span className="text-[#99A1AE] text-sm" >
									{"Accessibility"}
								</span>
							</div>
							<div className="flex flex-col items-start mr-[51px]">
								<span className="text-[#99A1AE] text-sm" >
									{"Sitemap"}
								</span>
							</div>
						</div>
					</div>
					<div className="flex justify-between items-center self-stretch mb-[45px] mx-20">
						<div className="flex shrink-0 items-center gap-[11px]">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/me6czjeo_expires_30_days.png"} 
								className="w-5 h-5 object-fill"
							/>
							<div className="flex flex-col shrink-0 items-start">
								<div className="flex flex-col items-start pr-[101px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Call Us"}
									</span>
								</div>
								<div className="flex flex-col items-start pr-[21px]">
									<span className="text-white text-base font-bold" >
										{"1-800-GO-Arrow"}
									</span>
								</div>
							</div>
						</div>
						<div className="flex shrink-0 items-center gap-[11px]">
							<img
								src={"https://storage.googleapis.com/tagjs-prod.appspot.com/v1/OBrP5JBWJ2/9cxrl0v1_expires_30_days.png"} 
								className="w-5 h-5 object-fill"
							/>
							<div className="flex flex-col shrink-0 items-start">
								<div className="flex flex-col items-start pr-[104px]">
									<span className="text-[#99A1AE] text-sm" >
										{"Email Us"}
									</span>
								</div>
								<div className="flex flex-col items-start">
									<span className="text-white text-base font-bold" >
										{"support@arrow.com"}
									</span>
								</div>
							</div>
						</div>
						<div className="w-[178px] h-[43px]">
						</div>
					</div>
					<div className="flex justify-between items-center self-stretch mx-20">
						<div className="flex flex-col shrink-0 items-start pt-[1px]">
							<span className="text-[#99A1AE] text-sm" >
								{"© 2026 Toyota Financial Services. All rights reserved."}
							</span>
						</div>
						<div className="flex flex-col shrink-0 items-start pt-[1px]">
							<span className="text-[#99A1AE] text-sm" >
								{"Project ARROW (331) • R1 Launch: March 31, 2026"}
							</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	)
}