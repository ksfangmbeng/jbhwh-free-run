"use client"

import { ArrowUpDown, Grid3X3, List } from "lucide-react"

interface SortControlsProps {
  sortBy: string
  onSortChange: (sort: string) => void
  view: "grid" | "list"
  onViewChange: (view: "grid" | "list") => void
  resultCount: number
}

export function SortControls({ sortBy, onSortChange, view, onViewChange, resultCount }: SortControlsProps) {
  return (
    <div className="flex items-center justify-between gap-4">
      <p className="text-sm text-muted-foreground">
        <span className="font-semibold text-foreground">{resultCount}</span> results
      </p>
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5">
          <ArrowUpDown className="h-3.5 w-3.5 text-muted-foreground" />
          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value)}
            className="text-sm text-foreground bg-transparent border-none focus:outline-none cursor-pointer font-medium"
          >
            <option value="recommended">Recommended</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="name">Name A-Z</option>
            <option value="mpg">Best MPG</option>
          </select>
        </div>
        <div className="flex items-center border border-border rounded-lg overflow-hidden">
          <button
            onClick={() => onViewChange("grid")}
            className={`p-2 transition-colors ${view === "grid" ? "bg-foreground text-card" : "text-muted-foreground hover:text-foreground"}`}
            aria-label="Grid view"
          >
            <Grid3X3 className="h-4 w-4" />
          </button>
          <button
            onClick={() => onViewChange("list")}
            className={`p-2 transition-colors ${view === "list" ? "bg-foreground text-card" : "text-muted-foreground hover:text-foreground"}`}
            aria-label="List view"
          >
            <List className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
