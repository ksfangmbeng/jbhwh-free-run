"use client"

import { X } from "lucide-react"

interface FilterChipsProps {
  activeFilters: string[]
  onRemoveFilter: (filter: string) => void
  onClearAll: () => void
}

export function FilterChips({ activeFilters, onRemoveFilter, onClearAll }: FilterChipsProps) {
  if (activeFilters.length === 0) return null

  return (
    <div className="flex items-center gap-2 flex-wrap">
      {activeFilters.map((filter) => (
        <button
          key={filter}
          onClick={() => onRemoveFilter(filter)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-full border border-border bg-transparent text-foreground text-xs font-normal hover:bg-card transition-colors group"
        >
          <span>{filter}</span>
          <X className="h-3 w-3 text-foreground opacity-60 group-hover:opacity-100 transition-opacity" />
        </button>
      ))}
      {activeFilters.length > 1 && (
        <button
          onClick={onClearAll}
          className="text-xs font-medium text-accent hover:underline px-2 py-2"
        >
          Clear all
        </button>
      )}
    </div>
  )
}
