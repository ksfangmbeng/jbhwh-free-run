export function ToyotaLogo({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 120 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Toyota"
    >
      <ellipse cx="30" cy="20" rx="28" ry="18" stroke="currentColor" strokeWidth="2" fill="none" />
      <ellipse cx="30" cy="20" rx="18" ry="12" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <ellipse cx="30" cy="20" rx="8" ry="18" stroke="currentColor" strokeWidth="1.5" fill="none" />
      <line x1="2" y1="20" x2="58" y2="20" stroke="currentColor" strokeWidth="1.5" />
      <text
        x="68"
        y="26"
        fontFamily="inherit"
        fontSize="16"
        fontWeight="700"
        fill="currentColor"
        letterSpacing="2"
      >
        TOYOTA
      </text>
    </svg>
  )
}
