"use client"

import { ChevronDown } from "lucide-react"
import { useState } from "react"

interface FilterSectionProps {
  title: string
  options: string[]
  activeFilters: string[]
  onToggleFilter: (filter: string) => void
  defaultOpen?: boolean
}

function FilterSection({ title, options, activeFilters, onToggleFilter, defaultOpen = false }: FilterSectionProps) {
  const [isOpen, setIsOpen] = useState(defaultOpen)

  return (
    <div className="border-b border-border">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between w-full py-4 text-sm font-semibold text-foreground"
      >
        <span>{title}</span>
        <ChevronDown className={`h-4 w-4 text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`} />
      </button>
      {isOpen && (
        <div className="pb-4 flex flex-col gap-2.5">
          {options.map((option) => {
            const isActive = activeFilters.includes(option)
            return (
              <label key={option} className="flex items-center gap-3 cursor-pointer group">
                <div
                  className={`h-4 w-4 rounded border flex items-center justify-center transition-colors ${
                    isActive
                      ? "bg-foreground border-foreground"
                      : "border-border group-hover:border-muted-foreground"
                  }`}
                >
                  {isActive && (
                    <svg className="h-3 w-3 text-card" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
                <input
                  type="checkbox"
                  checked={isActive}
                  onChange={() => onToggleFilter(option)}
                  className="sr-only"
                />
                <span className="text-sm text-foreground">{option}</span>
              </label>
            )
          })}
        </div>
      )}
    </div>
  )
}

interface SearchFiltersProps {
  activeFilters: string[]
  onToggleFilter: (filter: string) => void
}

const filterGroups = [
  {
    title: "Body Type",
    options: ["SUV", "Sedan", "Truck", "Hatchback", "Minivan", "Coupe"],
    defaultOpen: true,
  },
  {
    title: "Fuel Type",
    options: ["Gasoline", "Hybrid", "Plug-in Hybrid", "Electric"],
    defaultOpen: true,
  },
  {
    title: "Drivetrain",
    options: ["FWD", "AWD", "4WD", "RWD"],
    defaultOpen: false,
  },
  {
    title: "Price Range",
    options: ["Under $25K", "$25K - $35K", "$35K - $45K", "$45K - $55K", "Over $55K"],
    defaultOpen: false,
  },
  {
    title: "Seating",
    options: ["2 seats", "5 seats", "7 seats", "8 seats"],
    defaultOpen: false,
  },
]

export function SearchFilters({ activeFilters, onToggleFilter }: SearchFiltersProps) {
  return (
    <aside className="w-full lg:w-[260px] shrink-0">
      <div className="bg-card rounded-lg p-5">
        <h2 className="text-sm font-bold text-foreground uppercase tracking-wide mb-1">Filters</h2>
        {filterGroups.map((group) => (
          <FilterSection
            key={group.title}
            title={group.title}
            options={group.options}
            activeFilters={activeFilters}
            onToggleFilter={onToggleFilter}
            defaultOpen={group.defaultOpen}
          />
        ))}
      </div>
    </aside>
  )
}
