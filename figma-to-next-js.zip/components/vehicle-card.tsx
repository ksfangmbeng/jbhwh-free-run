"use client"

import Image from "next/image"
import { Heart } from "lucide-react"
import { useState } from "react"

export interface Vehicle {
  id: string
  name: string
  year: number
  type: string
  fuelType: string
  drivetrain: string
  seating: string
  startingPrice: string
  mpg: string
  image: string
  badge?: string
}

interface VehicleCardProps {
  vehicle: Vehicle
}

export function VehicleCard({ vehicle }: VehicleCardProps) {
  const [isFavorited, setIsFavorited] = useState(false)

  return (
    <article className="bg-card rounded-lg overflow-hidden group transition-shadow hover:shadow-lg">
      <div className="relative aspect-[16/10] bg-secondary overflow-hidden">
        <Image
          src={vehicle.image}
          alt={`${vehicle.year} ${vehicle.name}`}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-500"
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
        />
        {vehicle.badge && (
          <span className="absolute top-3 left-3 px-2.5 py-1 bg-accent text-accent-foreground text-[10px] font-bold uppercase tracking-wider rounded">
            {vehicle.badge}
          </span>
        )}
        <button
          onClick={() => setIsFavorited(!isFavorited)}
          className="absolute top-3 right-3 h-8 w-8 rounded-full bg-card/80 backdrop-blur-sm flex items-center justify-center hover:bg-card transition-colors"
          aria-label={isFavorited ? `Remove ${vehicle.name} from favorites` : `Add ${vehicle.name} to favorites`}
        >
          <Heart
            className={`h-4 w-4 transition-colors ${isFavorited ? "fill-[#CC0000] text-[#CC0000]" : "text-foreground"}`}
          />
        </button>
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-2">
          <div>
            <p className="text-xs text-muted-foreground font-medium">{vehicle.year}</p>
            <h3 className="text-base font-bold text-foreground mt-0.5 text-pretty">{vehicle.name}</h3>
          </div>
        </div>
        <div className="mt-3 flex items-center gap-3 flex-wrap">
          <span className="text-[11px] text-muted-foreground font-medium px-2 py-0.5 rounded-full bg-secondary">
            {vehicle.type}
          </span>
          <span className="text-[11px] text-muted-foreground font-medium px-2 py-0.5 rounded-full bg-secondary">
            {vehicle.fuelType}
          </span>
          <span className="text-[11px] text-muted-foreground font-medium px-2 py-0.5 rounded-full bg-secondary">
            {vehicle.drivetrain}
          </span>
        </div>
        <div className="mt-4 pt-3 border-t border-border flex items-end justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Starting MSRP</p>
            <p className="text-lg font-bold text-foreground">{vehicle.startingPrice}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Est. MPG</p>
            <p className="text-sm font-semibold text-foreground">{vehicle.mpg}</p>
          </div>
        </div>
        <button className="mt-4 w-full h-10 rounded-full border border-foreground text-foreground text-sm font-semibold hover:bg-foreground hover:text-card transition-colors">
          Explore
        </button>
      </div>
    </article>
  )
}
