"use client"

import { Search } from "lucide-react"

interface SearchHeroProps {
  query: string
  onQueryChange: (query: string) => void
  resultCount: number
}

export function SearchHero({ query, onQueryChange, resultCount }: SearchHeroProps) {
  return (
    <section className="relative px-6 lg:px-10 pt-8 pb-6">
      <div className="absolute inset-0 bg-gradient-to-b from-card to-transparent h-[240px] pointer-events-none" />
      <div className="relative max-w-3xl">
        <h1 className="text-3xl lg:text-4xl font-bold text-foreground tracking-tight text-balance">
          Find Your Toyota
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          {resultCount} vehicles available
        </p>
        <div className="mt-5 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <input
            type="text"
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Search by model, type, or feature..."
            className="w-full h-12 pl-12 pr-4 rounded-full border border-border bg-card text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-shadow"
          />
        </div>
      </div>
    </section>
  )
}
