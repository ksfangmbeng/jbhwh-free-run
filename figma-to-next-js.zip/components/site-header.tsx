"use client"

import Link from "next/link"
import { Menu, Search, User, MapPin } from "lucide-react"
import { ToyotaLogo } from "./toyota-logo"
import { Button } from "@/components/ui/button"

const navLinks = [
  { label: "Vehicles", href: "#" },
  { label: "Shopping Tools", href: "#" },
  { label: "Owners", href: "#" },
  { label: "About Toyota", href: "#" },
]

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-50 w-full bg-card">
      <div className="flex items-center justify-between px-6 lg:px-10 h-[72px]">
        <div className="flex items-center gap-8">
          <Link href="/" aria-label="Toyota Home">
            <ToyotaLogo className="h-8 w-auto text-foreground" />
          </Link>
          <nav className="hidden lg:flex items-center gap-6" aria-label="Main navigation">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                href={link.href}
                className="text-sm font-medium text-foreground hover:text-accent transition-colors"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" className="text-foreground" aria-label="Search">
            <Search className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground hidden sm:inline-flex" aria-label="Find a dealer">
            <MapPin className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground hidden sm:inline-flex" aria-label="Account">
            <User className="h-5 w-5" />
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground lg:hidden" aria-label="Menu">
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  )
}
