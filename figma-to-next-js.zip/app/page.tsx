"use client"

import { useState, useMemo } from "react"
import { SiteHeader } from "@/components/site-header"
import { SearchHero } from "@/components/search-hero"
import { FilterChips } from "@/components/filter-chips"
import { SearchFilters } from "@/components/search-filters"
import { SortControls } from "@/components/sort-controls"
import { VehicleGrid } from "@/components/vehicle-grid"
import type { Vehicle } from "@/components/vehicle-card"
import { SlidersHorizontal, X } from "lucide-react"

const vehicles: Vehicle[] = [
  {
    id: "1",
    name: "RAV4",
    year: 2026,
    type: "SUV",
    fuelType: "Hybrid",
    drivetrain: "AWD",
    seating: "5 seats",
    startingPrice: "$31,380",
    mpg: "41 combined",
    image: "/images/toyota-rav4.jpg",
    badge: "Best Seller",
  },
  {
    id: "2",
    name: "Camry",
    year: 2026,
    type: "Sedan",
    fuelType: "Gasoline",
    drivetrain: "FWD",
    seating: "5 seats",
    startingPrice: "$28,855",
    mpg: "32 combined",
    image: "/images/toyota-camry.jpg",
  },
  {
    id: "3",
    name: "Tacoma",
    year: 2026,
    type: "Truck",
    fuelType: "Gasoline",
    drivetrain: "4WD",
    seating: "5 seats",
    startingPrice: "$31,500",
    mpg: "24 combined",
    image: "/images/toyota-tacoma.jpg",
    badge: "New",
  },
  {
    id: "4",
    name: "Prius",
    year: 2026,
    type: "Hatchback",
    fuelType: "Hybrid",
    drivetrain: "FWD",
    seating: "5 seats",
    startingPrice: "$28,545",
    mpg: "57 combined",
    image: "/images/toyota-prius.jpg",
    badge: "Most Efficient",
  },
  {
    id: "5",
    name: "Highlander",
    year: 2026,
    type: "SUV",
    fuelType: "Hybrid",
    drivetrain: "AWD",
    seating: "7 seats",
    startingPrice: "$40,720",
    mpg: "36 combined",
    image: "/images/toyota-highlander.jpg",
  },
  {
    id: "6",
    name: "Corolla",
    year: 2026,
    type: "Sedan",
    fuelType: "Gasoline",
    drivetrain: "FWD",
    seating: "5 seats",
    startingPrice: "$22,950",
    mpg: "35 combined",
    image: "/images/toyota-corolla.jpg",
  },
]

export default function SearchPage() {
  const [query, setQuery] = useState("")
  const [activeFilters, setActiveFilters] = useState<string[]>([])
  const [sortBy, setSortBy] = useState("recommended")
  const [view, setView] = useState<"grid" | "list">("grid")
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)

  const toggleFilter = (filter: string) => {
    setActiveFilters((prev) =>
      prev.includes(filter) ? prev.filter((f) => f !== filter) : [...prev, filter]
    )
  }

  const removeFilter = (filter: string) => {
    setActiveFilters((prev) => prev.filter((f) => f !== filter))
  }

  const clearAllFilters = () => {
    setActiveFilters([])
  }

  const filteredVehicles = useMemo(() => {
    let results = vehicles

    if (query) {
      const q = query.toLowerCase()
      results = results.filter(
        (v) =>
          v.name.toLowerCase().includes(q) ||
          v.type.toLowerCase().includes(q) ||
          v.fuelType.toLowerCase().includes(q)
      )
    }

    if (activeFilters.length > 0) {
      results = results.filter((v) => {
        return activeFilters.some(
          (filter) =>
            v.type === filter ||
            v.fuelType === filter ||
            v.drivetrain === filter ||
            v.seating === filter
        )
      })
    }

    if (sortBy === "price-low") {
      results = [...results].sort(
        (a, b) => parseFloat(a.startingPrice.replace(/[^0-9.]/g, "")) - parseFloat(b.startingPrice.replace(/[^0-9.]/g, ""))
      )
    } else if (sortBy === "price-high") {
      results = [...results].sort(
        (a, b) => parseFloat(b.startingPrice.replace(/[^0-9.]/g, "")) - parseFloat(a.startingPrice.replace(/[^0-9.]/g, ""))
      )
    } else if (sortBy === "name") {
      results = [...results].sort((a, b) => a.name.localeCompare(b.name))
    } else if (sortBy === "mpg") {
      results = [...results].sort(
        (a, b) => parseFloat(b.mpg) - parseFloat(a.mpg)
      )
    }

    return results
  }, [query, activeFilters, sortBy])

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      <main>
        <SearchHero
          query={query}
          onQueryChange={setQuery}
          resultCount={filteredVehicles.length}
        />

        <div className="border-t border-border" />

        <div className="px-6 lg:px-10 py-6">
          <div className="flex items-center justify-between gap-4 mb-5">
            <FilterChips
              activeFilters={activeFilters}
              onRemoveFilter={removeFilter}
              onClearAll={clearAllFilters}
            />
            <button
              onClick={() => setMobileFiltersOpen(true)}
              className="lg:hidden flex items-center gap-2 px-4 py-2 rounded-full border border-border text-sm font-medium text-foreground"
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filters
            </button>
          </div>

          <div className="flex gap-8">
            {/* Desktop Sidebar */}
            <div className="hidden lg:block">
              <SearchFilters
                activeFilters={activeFilters}
                onToggleFilter={toggleFilter}
              />
            </div>

            {/* Mobile Filters Overlay */}
            {mobileFiltersOpen && (
              <div className="fixed inset-0 z-50 lg:hidden">
                <div
                  className="absolute inset-0 bg-foreground/50"
                  onClick={() => setMobileFiltersOpen(false)}
                />
                <div className="absolute right-0 top-0 h-full w-[320px] max-w-full bg-background overflow-y-auto">
                  <div className="flex items-center justify-between p-5 border-b border-border">
                    <h2 className="text-base font-bold text-foreground">Filters</h2>
                    <button
                      onClick={() => setMobileFiltersOpen(false)}
                      className="h-8 w-8 flex items-center justify-center rounded-full hover:bg-secondary text-foreground"
                      aria-label="Close filters"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                  <div className="p-5">
                    <SearchFilters
                      activeFilters={activeFilters}
                      onToggleFilter={toggleFilter}
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Results */}
            <div className="flex-1 min-w-0">
              <SortControls
                sortBy={sortBy}
                onSortChange={setSortBy}
                view={view}
                onViewChange={setView}
                resultCount={filteredVehicles.length}
              />
              <div className="mt-5">
                <VehicleGrid vehicles={filteredVehicles} />
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-border mt-16">
        <div className="px-6 lg:px-10 py-10">
          <div className="flex flex-col lg:flex-row items-start justify-between gap-8">
            <div>
              <p className="text-sm font-semibold text-foreground">Toyota Motor Sales, U.S.A., Inc.</p>
              <p className="mt-1 text-xs text-muted-foreground">
                All information applies to U.S. vehicles only.
              </p>
            </div>
            <div className="flex items-center gap-6">
              <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Privacy Policy</a>
              <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Legal Terms</a>
              <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Accessibility</a>
              <a href="#" className="text-xs text-muted-foreground hover:text-foreground transition-colors">Contact Us</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
